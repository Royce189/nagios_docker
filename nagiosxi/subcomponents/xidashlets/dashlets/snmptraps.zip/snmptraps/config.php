<div class="form-group">
    <label for="lookback_value"><?php echo _('Lookback'); ?></label>
    <div>
        <input type="text" name="lookback_value" class="form-control" id="snmptraps-dashlet-config-lookback_value" />
        <select name="lookback_unit" class="form-control" id="snmptraps-dashlet-config-lookback_unit">
            <option value="SECOND"><?php echo _("Seconds"); ?></option>
            <option value="MINUTE" selected><?php echo _("Minutes"); ?></option>
            <option value="HOUR"><?php echo _("Hours"); ?></option>
            <option value="DAY"><?php echo _("Days"); ?></option>
        </select>
    </div>
</div>

<div class="form-group">
    <label for="interval_value"><?php echo _('Bucket Size'); ?></label>
    <div>
        <input type="text" name="interval_value" class="form-control" id="snmptraps-dashlet-config-interval_value" />
        <select name="interval_unit" class="form-control" id="snmptraps-dashlet-config-interval_unit">
            <option value="SECOND"><?php echo _("Seconds"); ?></option>
            <option value="MINUTE" selected><?php echo _("Minutes"); ?></option>
            <option value="HOUR"><?php echo _("Hours"); ?></option>
            <option value="DAY"><?php echo _("Days"); ?></option>
        </select>
    </div>
</div>
