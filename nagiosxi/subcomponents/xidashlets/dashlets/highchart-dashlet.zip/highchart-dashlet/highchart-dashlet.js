function load_forms(hosts, hostgroups){
    // User is not authorized to view any hosts nor hostgroups
    if (hosts.length == 0 && hostgroups.length == 0){
        $("#child_popup_container").empty();
        $("#child_popup_container").append("<div id='popup_header'><b>"+_('ERROR: You are not authorized to use this report')+"</b></div>");
    }
    // User is only authorized to view specific hosts, not hostgroups
    else if (hostgroups.length == 0) {
        load_hosts(hosts);
        $("#hostgroup_select").addClass("hidden");
    }
    // I don't think this branch should ever be reached (can't monitor any hosts but can monitor hostgroups?)
    else if (hosts.length == 0) {
        load_hostgroups(hostgroups);
    }
    // User can view all hosts and hostgroups
    else {
        load_hosts(hosts);
        load_hostgroups(hostgroups);
    }
}
// Function used to load current hosts in both cool and normal mode
function load_hosts(hosts){
    var hostSelect = $("#hostChoiceSelect");
    $.each(hosts, function(index, host){
        hostSelect.append($("<option></option<").attr("value", host['host_name']).text(host['host_name']));
    });
}

// Function used to load current hostgroups in both cool and normal mode
function load_hostgroups(hostgroups){
    var hostgroupSelect = $("#hostgroupChoiceSelect");
    $.each(hostgroups, function(index, hostgroup){
        hostgroupSelect.append($("<option></option<").attr("value", hostgroup['hostgroup_name']).text(hostgroup['hostgroup_name']));
    });
}

// Function used to switch form options between host/sort select in both cool and normal mode
function switch_form1(option){
    if (option === 'pie' || option === 'donut'){
        $("#sort_select").addClass("hidden");
        $("#host_select").removeClass("hidden");
    } else {
        $("#host_select").addClass("hidden");
        $("#sort_select").removeClass("hidden");
    }
    switch_form2($("#hostgroupChoiceSelect").val());
}

// Function used to switch form options between host/hostgroup select in both cool and normal mode
function switch_form2(option){
    if (option !== 'default'){
        $("#host_select").addClass('hidden');
    }
    else {
        var graphChoice = $("#graphChoiceSelect").val();
        if (graphChoice === 'pie' || graphChoice === 'donut'){
            $("#host_select").removeClass('hidden');
        }
    }
}

// The functions below are only used in cool mode
function highchart_display_dashlet_created() {
    content = "<div id='child_popup_header' style='margin-bottom: 5px;'><b>"+_('Dashlet Added')+"</b></div><div id='child_popup_data'><p>"+_('The dashlet has been added and will now show up on your dashboard.')+"</p></div>";
    set_child_popup_content(content);
    display_child_popup();
    fade_child_popup('green');
}

function highchart_add_graph_to_dashlet() {
    var board = $('#boardName').val();
    var dashletname = $('#dashletName').val();
    var sortChoice = $('#sortChoice').val();
    var hostChoice = $('#hostChoice').val();
    var hostgroupChoice = $('#hostgroupChoice').val();
    var graphChoice = $('#graphChoice').val();

    if (!sortChoice){
        sortChoice = "default";
    }
    if (!hostChoice){
        hostChoice = "total";
    }
    if (!hostgroupChoice){
        hostgroupChoice = "default";
    }
    url = "/nagiosxi/includes/dashifygraph.php";

    // Send request to dashify
    $.post(url, {dashletName: dashletname, boardName: board, sortChoice: sortChoice, graphChoice: graphChoice, sortChoice: sortChoice, hostChoice: hostChoice, hostgroupChoice: hostgroupChoice}, function (data) {
        // If it was a success show created message
        if (data.success == 1) {
            highchart_display_dashlet_created();
        }
    }, 'json');
}

function highchart_add_formdata(){
    hide_throbber();
    // Prob not the best way to do this (based it off of existing code)
    // - requires each dashlet on the page to have these values
    // - changes and uses the value of the first set each time any are selected
    $('#boardName').val($('#addToDashboardBoardSelect').val()); //assign select value to hidden input
    $('#dashletName').val($('#addtoDashboardTitleBox').val()); //assign dashboard title to hidden input
    $('#graphChoice').val($('#graphChoiceSelect').val()); //assign graph choice value to hidden input
    $('#sortChoice').val($('#sortChoiceSelect').val()); //assign sort choice value to hidden input
    $('#hostChoice').val($('#hostChoiceSelect').val()); //assign sort choice value to hidden input
    $('#hostgroupChoice').val($('#hostgroupChoiceSelect').val());

    if ($('#boardName').val() != '' && $('#graphChoice').val() != '') {
        highchart_add_graph_to_dashlet();
    }
    else {
        alert(_('You must fill out the entire form.'));
    }
}

function dashify_highchart(graphChoice, sortChoice, hostChoice, hostgroupChoice, hosts, hostgroups){
    show_throbber();
    
    get_ajax_data_innerHTML("getdashboardselectmenuhtml", "", true, '#addToDashboardBoardSelect');
    
    var content = "<div id='popup_header'><b>" + _("Add to Dashboard") + "</b></div><div id='popup_data'><p>" + _("Add this powerful little dashlet to one of your dashboards for visual goodness.") + "</p></div>";
    content += "<label for='addToDashboardTitleBox'>" + _("Dashlet Title") + "</label><br class='nobr' />";
    content += "<input type='text' size='30' name='title' id='addtoDashboardTitleBox' value='"+_('My Graph')+"' class='form-control' />";
    content += "<br><br class='nobr' /><label for='addToDashboardBoardSelect'>" + _("Select a Dashboard to Add To") + "</label><br class='nobr' />";
    content += "<select class='form-control' id='addToDashboardBoardSelect'></select>";
    content += "<br><br class='nobr' /><label for='graphChoiceSelect'>" + _("Graph Type") + "</label><br class='nobr' />";
    content += "<select class='form-control' id='graphChoiceSelect' onchange='switch_form1(this.value)'>";
    content += "<option value='bar' id='bar'>" + _("Bar Chart") + "</option>";
    content += "<option value='barstacked' id='barstacked'>" + _("Stacked Bar Chart") + "</option>";
    content += "<option value='column' id='column'>" + _("Column Chart") + "</option>";
    content += "<option value='columnstacked' id='columnstacked'>" + _("Stacked Column Chart") + "</option>";
    content += "<option value='columnpyramid' id='columnpyramid'>" + _("Pyramid Column Chart") + "</option>";
    content += "<option value='radial' id='radial'>" + _("Radial Column Chart") + "</option>";
    content += "<option value='line' id='line'>" + _("Line Graph") + "</option>";
    content += "<option value='spline' id='spline'>" + _("Spline Graph") + "</option>";
    content += "<option value='area' id='area'>" + _("Area Chart") + "</option>";
    content += "<option value='areaspline' id='areaspline'>" + _("Spline Area Chart") + "</option>";
    content += "<option value='pie' id='pie'>" + _("Pie Chart") + "</option>";
    content += "<option value='donut' id='donut'>" + _("Donut Chart") + "</option>";
    content += "</select></div>";

    content += "<div id='hostgroup_select'><br><label for='hostgroupChoiceSelect'>" + _("Organize by Hostgroup") + "</label><br class='nobr' />";
    content += "<select class='form-control' id='hostgroupChoiceSelect' onchange='switch_form2(this.value)'>";
    content += "<option value='default' id='default'>" + _("Disabled") + "</option>";
    content += "<option value='all_hostgroups' id='all_hostgroups'>" + _("All Hostgroups") + "</option>";
    content += "</select></div>";

    content += "<div id='sort_select'><br><label for='sortChoiceSelect'>" + _("Sort By") + "</label><br class='nobr' />";
    content += "<select class='form-control' id='sortChoiceSelect'>";
    content += "<option value='default' id='default'>" + _("Host Name") + "</option>";
    content += "<option value='total_ok' id='total_ok'>" + _("Total Ok") + "</option>";
    content += "<option value='total_warning' id='total_warning'>" + _("Total Warning") + "</option>";
    content += "<option value='total_unknown' id='total_unknown'>" + _("Total Unknown") + "</option>";
    content += "<option value='total_critical' id='total_critical'>" + _("Total Critical") + "</option>";
    content += "</select></div>";
    
    content += "<div id='host_select'><br><label for='hostChoiceSelect'>" + _("Host") + "</label><br class='nobr' />";
    content += "<select class='form-control' id='hostChoiceSelect'>";
    content += "<option value='total' id='total'>" + _("All Hosts") + "</option>";
    content += "</select></div>";
    
    content += "<div id='addToDashboardFormButtons' style='margin-top:5px;'><br><button class='btn btn-sm btn-primary' id='AddToDashButton' onclick='highchart_add_formdata()'>" + _('Add It') + "</button></div>";

    hide_throbber();
    set_child_popup_content(content);
    // Sets the default form-choice values to those shown in the graphs
    $("#" + graphChoice).prop("selected", "selected");
    $("#" + sortChoice).prop("selected", "selected");
    load_forms(hosts, hostgroups);
    switch_form2(hostgroupChoice);
    switch_form1(graphChoice);
    $("#" + hostChoice).prop("selected", "selected");
    $("#" + hostgroupChoice).prop("selected", "selected");
    display_child_popup();
}