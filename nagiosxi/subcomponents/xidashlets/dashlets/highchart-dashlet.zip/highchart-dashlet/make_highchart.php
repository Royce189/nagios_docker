<?php

require_once(dirname(__FILE__) . '/../../common.inc.php');

// Graphs will not generate if error messaging turned on
ini_set('display_errors', 'off');

// Initialization stuff
pre_init();
init_session();

// Grab GET or POST variables and check pre-reqs
grab_request_vars();
check_prereqs();
check_authentication(false);

route_request();

// Comparison functions for use in usort - prob a nicer way to do this
function cmp_ok($a, $b)
{
    return $b['ok'] - $a['ok'];
}

function cmp_warning($a, $b)
{
    return $b['warning'] - $a['warning'];
}

function cmp_critical($a, $b)
{
    return $b['critical'] - $a['critical'];
}

function cmp_unknown($a, $b)
{
    return $b['unknown'] - $a['unknown'];
}

function route_request()
{
    $mode = grab_request_var("mode", "");
    switch ($mode) {
        case "getbetterchart":
            get_better_highcharts();
            break;    
        case "coolmodeactivated":
            get_cool_highcharts();
            break;
        default:
            break;
    }
}

// Core function that defines $output, building the actual highchart
function build_highchart($services, $host_names, $link_labels, $title, $subtitle){
    
    $divId = grab_request_var("divId", "");
    $width = grab_request_var("width", 400);
    $height = grab_request_var("height", 300) - 30;
    $charttype = grab_request_var("graphChoiceSelect", "column");
    $animation = grab_request_var("animation", "false");

    if ($title == "" && ($charttype == "pie" || $charttype == "donut")){
        $title = "All Hosts";
    }
    
    $oks = $services[0];
    $warnings = $services[1];
    $criticals = $services[2];
    $unknowns = $services[3];

    $donut = 0;
    $radial = 0;
    $stacked = 0;

    if ($charttype == 'donut'){
        $charttype = 'pie';
        $donut = 1;
    }

    else if ($charttype == 'radial'){
        $charttype = 'column';
        $radial = 1;
    }

    else if ($charttype == 'barstacked'){
        $charttype = 'bar';
        $stacked = 1;
    }

    else if ($charttype == 'columnstacked'){
        $charttype = 'column';
        $stacked = 1;
    }

    $color = "#000000";
    $colors = '["#b2ff5f", "#FEFF5F", "#FFC45F", "#FF795F"]';
    $theme = get_theme();
    if ($theme == "xi5dark") {
        $color = '#EEEEEE';
    }
    else if ($theme == "colorblind") {
        $colors = '["#56B4E9", "#D55E00", "#F0E442", "#CC79A7"]';
    }
    else if ($theme == "neptune") {
        $color = "#e1e7ef";
        $colors =  '["#52ef5a", "#eaff05", "#eba71e" , "#f0050e"]';
    }

    // Base chart options regardless of type
    $output = '<script type="text/javascript">
    Highcharts.setOptions({
        colors: ' . $colors . '
    });
    var chart_' . $divId . ';
    var options = {
        legend: {
            backgroundColor: "transparent"
        },
        chart: {
            backgroundColor: "transparent",
            renderTo: "' . $divId . '",
            width: ' . $width . ',
            height: ' . $height . ',
            type: "'. $charttype . '"';

    if ($radial) {
        $output .= 
        ', 
        polar: true,
        inverted: true';
    }
    $output .= 
        '},
        credits: {
            enabled: false
        },
        title: {
            text: "' . $title . '"
        },
        subtitle: {
            text: "' . $subtitle . '"
        },';
    if ($stacked){
        $output .= '
        plotOptions: {
            series: {
                stacking: "normal"
            }
        },';
    }
    // Organize data to fit pie / donut charts
    if ($charttype == 'pie') {

        $data = array(0, 0, 0, 0);
        $num_services = array_sum($oks) + array_sum($warnings) + array_sum($criticals) + array_sum($unknowns);
        $num_hosts = count($host_names);
        
        for ($x = 0; $x < $num_hosts; $x++) {
            $data[0] += $oks[$x];
            $data[1] += $warnings[$x];
            $data[2] += $unknowns[$x];
            $data[3] += $criticals[$x];
        }

        for ($x = 0; $x < 4; $x++) {
            $data[$x] = $data[$x] / $num_services * 100;
        }

        $formatted_data = array(
            array("name" => "Ok", "y" => round($data[0], 3)),
            array("name" => "Warning", "y" => round($data[1], 3)),
            array("name" => "Unknown", "y" => round($data[2], 3)),
            array("name" => "Critical", "y" => round($data[3], 3))
        );
        
        $output .= 
        'plotOptions: {
            pie: {
                dataLabels: {
                    useHTML: true,
                    enabled: false,
                    color: "'.$color.'",
                    connectorColor: "'.$color.'",
                    format: "{point.name} {point.percentage:.2f}%",
                    distance: 10
                }
            }
        },
        series: [{';
            
        // Add innersize if donut chart
        if ($donut){
            $output .= 
            'innerSize: "65%",';
        }
            
        $output .= 
        'data: '.json_encode($formatted_data).',
        animation: '.($animation).'
        }]';

    // If not pie / donut, use data as is - sort according to user's selection
    } else {
        // Encode arrays to be used in highchart
        $json_host_names = json_encode($host_names);
        $json_oks = json_encode($oks);
        $json_warnings = json_encode($warnings);
        $json_criticals = json_encode($criticals);
        $json_unknowns = json_encode($unknowns);
        $output .=
            'xAxis: {
                categories: ' . $json_host_names . ',
                title: {
                    text: null
                },
                gridLineWidth: 0,
                lineWidth: 0,
                ';
        if ($link_labels){
            $base_url = '/nagiosxi/includes/components/xicore/status.php?show=';
            if (grab_request_var("hostgroupChoiceSelect", "default") == "all_hostgroups"){
                $base_url .= 'hosts&hostgroup=';
            }
            else {
                $base_url .= 'hostdetail&host=';
            }
            $output .= 
                'labels: {
                    formatter: function () {
                        return "<a href=' . $base_url . '" + this.value + " target=' . '_blank' . '>" + this.value + "</a>"
                    },
                    useHTML: true
                }';
        }
        $output .= 
            '},
            yAxis: {
                title: {
                    text: null
                }
            },
            series: [{
                name: "Ok",
                data: ' . $json_oks . ',
                animation: '.($animation).',
                groupPadding: 0.0
            }, {
                name: "Warning",
                data: ' . $json_warnings . ',
                animation: '.($animation).',
                groupPadding: 0.0
            }, {
                name: "Unknown",
                data: ' . $json_unknowns . ',
                animation: '.($animation).',
                groupPadding: 0.0
            }, {
                name: "Critical",
                data: ' . $json_criticals . ',
                animation: '.($animation).',
                groupPadding: 0.0
            }]';
    }
    $output .= '
    }
    chart_' . $divId . ' = new Highcharts.Chart(options);
    </script>';
    return $output;
}

function get_all_hostgroup_data(&$host_names){
    $sorted = array();
    $hostgroups = get_data_hostgroup_members(array());
    foreach ($hostgroups as $hostgroup){
        $members = $hostgroup["members"];
        foreach($members as $member){
            $ok = 0;
            $warning = 0;
            $critical = 0;
            $unknown = 0;
            foreach($member as $host){
                $temp = array();
                $services_by_name = get_data_service_status(array('host_name' => $host["host_name"]));
                for ($y = 0; $y < sizeof($services_by_name); $y++) {
                    array_push($temp, $services_by_name[$y]['current_state']);    
                }
                $ok += count(array_keys($temp, 0));
                $warning += count(array_keys($temp, 1));
                $critical += count(array_keys($temp, 2));
                $unknown += count(array_keys($temp, 3));
            }
            $sort_array = array('name' => $hostgroup["hostgroup_name"], 'ok' => $ok, 'warning' => $warning, 'critical' => $critical, 'unknown' => $unknown);
            array_push($sorted, $sort_array);
            array_push($host_names, $hostgroup["hostgroup_name"]);
        }
    }
    return $sorted;
}

function get_host_data(&$host_names){

    $num_hosts = sizeof($host_names);
    $sorted = array();
	$service_statuses = array(); // 2D array of service states indexed by hosts
	
	for ($x = 0; $x < $num_hosts; $x++) {
		$services_by_name = get_data_service_status(array('host_name' => $host_names[$x])); // slow, could be improved
		$temp = array();
		for ($y = 0; $y < sizeof($services_by_name); $y++) {
			array_push($temp, $services_by_name[$y]['current_state']);
		}
		//array_push($service_statuses, $temp);
        $ok = count(array_keys($temp, 0));
		$warning = count(array_keys($temp, 1));
		$critical = count(array_keys($temp, 2));
		$unknown = count(array_keys($temp, 3));
        $sort_array = array('name' => $host_names[$x], 'ok' => $ok, 'warning' => $warning, 'critical' => $critical, 'unknown' => $unknown);
        array_push($sorted, $sort_array);
	}
    return $sorted;
}

// Gets and organizes internal data for use in a custom dashlet
function get_better_highcharts(){

    $sort_choice = grab_request_var("sortChoiceSelect", "default");
    $host_choice = grab_request_var("hostChoiceSelect", "total");
    $hostgroup_choice = grab_request_var("hostgroupChoiceSelect", "default");
    $title = "";

    $host_names = array();
    $sorted = array();

    // User chose to organize by all hostgroups
    if ($hostgroup_choice == "all_hostgroups"){
        // Functionality differs enough to isolate this to a different function entirely
        $title = "";
        $sorted = get_all_hostgroup_data($host_names);
    }
    
    // User chose to organize by a specific hostgroup
    else if ($hostgroup_choice != "default") {
        $title = $hostgroup_choice;
        $all_hostgroups = get_data_hostgroup_members(array());
        foreach($all_hostgroups as $hostgroup){
            if ($hostgroup["hostgroup_name"] == $hostgroup_choice){
                foreach($hostgroup["members"]["host"] as $host){
                    array_push($host_names, $host['host_name']);
                }
            }
        }
        $sorted = get_host_data($host_names);
    }

    // User chose not to organize by any hostgroup(s)

    // User chose to gather data for all hosts
    else if ($host_choice == "total") {
        $title = "";
        $all_hosts = get_data_host(array());
        foreach($all_hosts as $host){
            array_push($host_names, $host['host_name']);
        }
        $sorted = get_host_data($host_names);
    }

    // User chose to gather data for a specific host  
    else {
        $title = $host_choice;
        $host_names = array($host_choice);
        $sorted = get_host_data($host_names);
    }

    $num_hosts = count($host_names);

	// Organize the number of ok, warning, and critical services into arrays indexed by hosts
	$oks = array();
	$warnings = array();
	$criticals = array();
	$unknowns = array();
    
    switch($sort_choice){
        case('total_ok'):
            usort($sorted, "cmp_ok");
            break;
        case('total_warning'):
            usort($sorted, "cmp_warning");
            break;
        case('total_unknown'):
            usort($sorted, "cmp_unknown");
            break;
        case('total_critical'):
            usort($sorted, "cmp_critical");
            break;
        default:
            break;
    }
   
    for ($x = 0; $x < $num_hosts; $x++) {
		array_push($oks, $sorted[$x]['ok']);
		array_push($warnings, $sorted[$x]['warning']);
		array_push($criticals, $sorted[$x]['critical']);
		array_push($unknowns, $sorted[$x]['unknown']);
	}

    // This block exists solely because it felt weird to pass this many variables to a function
    $service_arr = array();
    array_push($service_arr, $oks);
    array_push($service_arr, $warnings);
    array_push($service_arr, $criticals);
    array_push($service_arr, $unknowns);
    
    $output = build_highchart($service_arr, $host_names, 1, $title, $subtitle);
    print $output;
    die();
}

// Hard-codes fake data for use in the cool dashlets for the cool dashboard
function get_cool_highcharts(){

    $iteration = grab_request_var("coolMode", "");
    $service_arr = array();
    $host_names = array();
    $title = "";
    $subtitle = "";

    if ($iteration == 1) {
        $service_arr = array(
            array(10, 4, 3, 1, 11, 12, 5, 7, 6, 15, 12, 2, 9, 4, 7),
            array(4, 1, 2, 3, 1, 5, 4, 3, 0, 0, 5, 5, 1, 6, 1),
            array(2, 3, 4, 2, 1, 0, 0, 0, 3, 1, 1, 0, 2, 6, 7),
            array(1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 2, 1, 3, 0, 0)
        );
        $host_names = array("Host1", "Host2", "Host3", "Host4", "Host5", "Host6", "Host7", "Host8", "Host9", "Host10", "Host11", "Host12", "Host13", "Host14", "Host15");
    }

    else if ($iteration == 2){
        $service_arr = array(
            array(10, 4, 3, 1, 11, 12, 5, 7, 6, 15, 12, 2, 9, 4, 7),
            array(4, 1, 2, 3, 1, 5, 4, 3, 0, 0, 5, 5, 1, 6, 1),
            array(7, 6, 4, 3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0),
            array(1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 2, 1, 3, 0, 0)
        );
        $host_names = array("Host1", "Host2", "Host3", "Host4", "Host5", "Host6", "Host7", "Host8", "Host9", "Host10", "Host11", "Host12", "Host13", "Host14", "Host15");
    }

    else if ($iteration == 3){
        $service_arr = array(
            array(10),
            array(4),
            array(2),
            array(1)
        );
        $host_names = array("Host1");
        $title = "Host7";
    }

    else if ($iteration == 4){
        $service_arr = array(
            array(7, 2, 3, 1, 11, 12, 5, 7, 9, 15, 12, 22, 9, 4, 7),
            array(4, 1, 2, 3, 12, 5, 4, 3, 4, 0, 5, 5, 1, 6, 1),
            array(2, 3, 4, 2, 1, 0, 0, 2, 3, 1, 1, 0, 2, 6, 7),
            array(1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 2, 1, 3, 0, 1)
        );
        $host_names = array("Host1", "Host2", "Host3", "Host4", "Host5", "Host6", "Host7", "Host8", "Host9", "Host10", "Host11", "Host12", "Host13", "Host14", "Host15");
        $title = "All Hosts";
    }

    else if ($iteration == 5){
        $service_arr = array(
            array(7, 9, 8),
            array(4, 1, 2),
            array(2, 3, 4),
            array(1, 0, 0)
        );
        $host_names = array("Group1", "Group2", "Group3");
    }

    else if ($iteration == 6){
        $service_arr = array(
            array(10, 4, 3, 12, 10, 12, 5, 10, 6, 15, 12, 18, 9, 4, 7, 4, 19, 18, 1, 10, 11, 3, 4, 6, 17, 10),
            array(4, 1, 2, 2, 1, 5, 4, 3, 8, 0, 5, 5, 1, 6, 1, 6, 5, 3, 2, 1, 6, 7, 8, 0, 0, 1),
            array(7, 6, 1, 3, 6, 2, 2, 1, 1, 1, 1, 0, 0, 0, 0, 2, 5, 6, 1, 2, 7, 8, 1, 0, 1, 1),
            array(1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 2, 1, 3, 0, 0, 1, 2, 4, 0, 0, 1, 0, 0, 0, 1, 0)
        );
        $host_names = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
            "S", "T", "U", "V", "W", "X", "Y", "Z");
    }
    
    $output = build_highchart($service_arr, $host_names, 0, $title, $subtitle);
    print $output;
    die();
}
