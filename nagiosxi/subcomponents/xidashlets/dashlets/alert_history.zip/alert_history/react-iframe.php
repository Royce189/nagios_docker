<iframe id="iframe-<?php echo $container; ?>" style="width: 1000px; height: 400px" scrolling="no" frameborder=0 src="" style="overflow: hidden;"></iframe>

<script>


$(document).ready(function() {

	<?php 
	    $url = get_base_url().'/includes/dashlets/alert_history/index.html?';
	    $url .= "&nsp=".get_nagios_session_protector_id();
	    $url .= "&container=".$container;
	    $url .= "&end=" . date("Y-m-d");
	    $url .= "&lookback=" . $lookback;
	    $url .= "&theme=" . get_theme();
	?>

	var the_iframe = document.getElementById("iframe-<?php echo $container; ?>");
	var url = '<?php echo $url;?>';
    the_iframe.src = url;
});

</script>