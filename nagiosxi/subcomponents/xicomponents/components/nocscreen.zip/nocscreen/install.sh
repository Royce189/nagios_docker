#!/bin/sh

BASEDIR=$(dirname $(readlink -f $0))
cd $BASEDIR

. $BASEDIR/../../../../var/xi-sys.cfg

chmod 775 $proddir/html/sounds/alarm -R
$chownbin root:root $proddir/html/sounds/.htaccess
$chownbin $apacheuser:$nagiosgroup $proddir/html/sounds/alarm -R

exit 0