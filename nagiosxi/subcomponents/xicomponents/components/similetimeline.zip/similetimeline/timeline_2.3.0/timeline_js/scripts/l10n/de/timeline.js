/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["de"] = {
    wikiLinkLabel: "Diskutieren"
};
