    <!--                                   -->
    <!-- The initial data set from Step 1. -->
    <!--                                   -->
    <input type="hidden" id="hostname" name="hostname" value="<?= encode_form_val($hostname) ?>">
    <input type="hidden" id="operation" name="operation" value="<?= encode_form_val($operation) ?>">
    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>">
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
        <h2 class="mb-2"><?= _('Remote Host Details') ?></h2>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="ip_address" class="form-label"><?= _('IP Address') ?> </label>
                <div class="input-group input-group-sm">
                    <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter IP Address") ?>" readonly="on">
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-sm-6">
                <label for="hostname" class="form-label"><?= _('Host Name') ?> </label>
                <div class="input-group input-group-sm position-relative">
                    <input type="text" name="hostname" id="hostname" value="<?= encode_form_val($hostname) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Host Name") ?>" >
                    <div class="invalid-feedback">
                        <?= _("Please enter the ".$labelText) ?>
                    </div>
                    <i id="hostname_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>
<?php 
    $hide_exists = "visually-hidden";

    if (array_key_exists("exist", $check_types)) {
        $hide_exists = "";
    }

    $placeholders = array(
        'description' => _('Docker - Containers Exist'),
        'warning' => "50:",
        'critical' => '30:',
        'timeout' => '0'
    );

    foreach ($placeholders as $index => $value) {
        if (!array_key_exists('exists', $serviceargs) || !array_key_exists($index, $serviceargs['exist'])) {
            $serviceargs['exist'][$index] = $value;
        }
    }
?>
        <div id="configure-exist" class="<?= $hide_exists ?> col-sm-8 border-block mb-2">
            <h2 class="mb-2"><?= _('Existing Containers') ?></h2>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[exist][description]" class="form-check-label bold"><?= _('Service Description') ?> <?= xi6_info_tooltip(_('Warning: If you have another service with the same description, it will be overwritten by this service')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[exist][description]" id="serviceargs[exist][description]" value="<?= encode_form_val($serviceargs['exist']['description']) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter the Service Description") ?>" >
                        <div class="invalid-feedback">
                            <?= _("Please enter the Service Description") ?>
                        </div>
                        <i id="serviceargs_exist_description_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[exist][warning]" class="form-check-label bold"><?= _('Thresholds') ?>  <?= xi6_info_tooltip(_('Enter a value like \'10:\' to alert if there are fewer than 10 containers. Enter a value like \'10\' to alert if there are more than 10 containers.')) ?><label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                        </span>
                        <input type="text" name="serviceargs[exist][warning]" id="serviceargs[exist][warning]" value="<?= encode_form_val($serviceargs['exist']['warning']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_exist_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                        </span>
                        <input type="text" name="serviceargs[exist][critical]" id="serviceargs[exist][critical]" value="<?= encode_form_val($serviceargs['exist']['critical']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_exist_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[exist][timeout]" class="form-check-label bold"><?= _('Timeout') ?> <?= xi6_info_tooltip(_('Enter 0 to never time out the check')) ?></label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[exist][timeout]" id="serviceargs[exist][timeout]" value="<?= encode_form_val($serviceargs['exist']['timeout']) ?>" class=" form-control form-control-sm monitor">
                        <span class="input-group-text"><?= _('sec') ?></span>
                        <i id="serviceargs_exist_timeout_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

        </div> <!-- configure-exist -->
<?php 
    $hide_running = "visually-hidden";

    if (array_key_exists("running", $check_types)) {
        $hide_running = "";
    }

    $placeholders = array(
        'description' => _('Docker - Containers Are Running'),
        'warning' => "50:",
        'critical' => '30:',
        'timeout' => '0',
        'bad' => 'on',
        'percentage' => '',
    );

    foreach ($placeholders as $index => $value) {
        if (!array_key_exists('running', $serviceargs) || !array_key_exists($index, $serviceargs['running'])) {
            $serviceargs['running'][$index] = $value;
        }
    }
?>
        <div id="configure-running" class="<?= $hide_running ?> col-sm-8 border-block mb-2">
            <h2 class="mb-2"><?= _('Running Containers') ?></h2>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[running][description]" class="form-check-label bold"><?= _('Service Description') ?> <?= xi6_info_tooltip(_('Warning: If you have another service with the same description, it will be overwritten by this service')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[running][description]" id="serviceargs[running][description]" value="<?= encode_form_val($serviceargs['running']['description']) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Service Description") ?>" >
                        <div class="invalid-feedback">
                            <?= _("Please enter the Service Description") ?>
                        </div>
                        <i id="serviceargs_running_description_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[running][warning]" class="form-check-label bold"><?= _('Thresholds') ?>  <?= xi6_info_tooltip(_('Enter a value like \'10:\' to alert if there are fewer than 10 containers. Enter a value like \'10\' to alert if there are more than 10 containers.')) ?><label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                        </span>
                        <input type="text" name="serviceargs[running][warning]" id="serviceargs[running][warning]" value="<?= encode_form_val($serviceargs['running']['warning']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_running_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                        </span>
                        <input type="text" name="serviceargs[running][critical]" id="serviceargs[running][critical]" value="<?= encode_form_val($serviceargs['running']['critical']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_running_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[running][timeout]" class="form-check-label bold"><?= _('Timeout') ?> <?= xi6_info_tooltip(_('Enter 0 to never time out the check')) ?></label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[running][timeout]" id="serviceargs[running][timeout]" value="<?= encode_form_val($serviceargs['running']['timeout']) ?>" class=" form-control form-control-sm monitor">
                        <span class="input-group-text"><?= _('sec') ?></span>
                        <i id="serviceargs_running_timeout_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="running-bad" class="form-check-input" name="serviceargs[running][bad]"  <?= is_checked($serviceargs['running']['bad']) ?> >
                    <label for="running-bad" class="form-check-label bold"><?= _('List Non-Running Containers') ?></label>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="running-percentage" class="form-check-input" name="serviceargs[running][percentage]"  <?= is_checked($serviceargs['running']['percentage']) ?> >
                    <label for="running-percentage" class="form-check-label bold"><?= is_checked($serviceargs['running']['percentage']) ?><?= _('Express thresholds as a percentage') ?></label>
                </div>
            </fieldset>
        </div> <!-- configure-running -->
<?php
    $hide_healthy = "visually-hidden";

    if (array_key_exists("healthy", $check_types)) {
        $hide_healthy = "";
    }

    $placeholders = array(
        'description' => _('Docker - Containers Are Healthy'),
        'warning' => "50:",
        'critical' => '30:',
        'timeout' => '0',
        'bad' => 'on',
        'percentage' => '',
        'no-healthcheck' => 'ignored',
    );

    foreach ($placeholders as $index => $value) {
        if (!array_key_exists('healthy', $serviceargs) || !array_key_exists($index, $serviceargs['healthy'])) {
            $serviceargs['healthy'][$index] = $value;
        }
    }
?>
        <div id="configure-healthy" class="<?= $hide_healthy ?> col-sm-8 border-block mb-2">

            <h2 class="mb-2"><?= _('Healthy Containers') ?></h2>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[healthy][description]" class="form-check-label bold"><?= _('Service Description') ?> <?= xi6_info_tooltip(_('Warning: If you have another service with the same description, it will be overwritten by this service')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[healthy][description]" id="serviceargs[healthy][description]" value="<?= encode_form_val($serviceargs['healthy']['description']) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Service Description") ?>" >
                        <div class="invalid-feedback">
                            <?= _("Please enter the Service Description") ?>
                        </div>
                        <i id="serviceargs_healthy_description_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[healthy][warning]" class="form-check-label bold"><?= _('Thresholds') ?>  <?= xi6_info_tooltip(_('Enter a value like \'10:\' to alert if there are fewer than 10 containers. Enter a value like \'10\' to alert if there are more than 10 containers.')) ?><label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                        </span>
                        <input type="text" name="serviceargs[healthy][warning]" id="serviceargs[healthy][warning]" value="<?= encode_form_val($serviceargs['healthy']['warning']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_healthy_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">
                            <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                        </span>
                        <input type="text" name="serviceargs[healthy][critical]" id="serviceargs[healthy][critical]" value="<?= encode_form_val($serviceargs['healthy']['critical']) ?>" class="form-control form-control-sm monitor">
                        <i id="serviceargs_healthy_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[healthy][timeout]" class="form-check-label bold"><?= _('Timeout') ?> <?= xi6_info_tooltip(_('Enter 0 to never time out the check')) ?></label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[healthy][timeout]" id="serviceargs[healthy][timeout]" value="<?= encode_form_val($serviceargs['healthy']['timeout']) ?>" class=" form-control form-control-sm monitor">
                        <span class="input-group-text"><?= _('sec') ?></span>
                        <i id="serviceargs_healthy_timeout_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="healthy-bad" class="form-check-input" name="serviceargs[healthy][bad]" <?= is_checked($serviceargs['healthy']['bad']) ?>>
                    <label for="healthy-bad" class="form-check-label bold"><?= _('List Non-healthy Containers') ?></label>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="healthy-percentage" class="form-check-input" name="serviceargs[healthy][percentage]" <?= is_checked($serviceargs['healthy']['percentage']) ?>>
                    <label for="healthy-percentage" class="form-check-label bold"><?= ('Express thresholds as a percentage') ?></label>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="no-healthcheck" class="form-check-label bold"><?= _('Missing Health Status') ?> <?= xi6_info_tooltip(_('Preferred status when a container\'s health check is unavailable.')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group position-relative">
                        <select name="serviceargs[healthy][no-healthcheck]" id="no-healthcheck" class="form-select form-select-sm form-control-sm monitor rounded">
                            <option value="ignored" <?= is_selected($serviceargs['healthy']['no-healthcheck'], 'ignored');?>><?= _(' ignored') ?></option>
                            <option value="healthy" <?= is_selected($serviceargs['healthy']['no-healthcheck'], 'healthy');?>><?= _(' counted as a healthy container') ?></option>
                            <option value="unhealthy" <?= is_selected($serviceargs['healthy']['no-healthcheck'], 'unhealthy');?>><?= _(' counted as an unhealthy container') ?></option>
                        </select>
                        <div class="invalid-feedback">
                            Please select the missing health check option.
                        </div>
                        <i id="version_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>
        </div> <!-- configure-healthy -->
<?php
    $hide_cpu = "visually-hidden";
    $hide_all_table = "visually-hidden";
    $hide_containers_table = "visually-hidden";
    $hide_networks_table = "visually-hidden";

    if ($list_type === "all") {
        $hide_all_table = "";
    } elseif ($list_type === "containers") {
        $hide_containers_table = "";
    } elseif ($list_type === "networks") {
        $hide_networks_table = "";
    }

    if (array_key_exists("cpu", $check_types)) {
        $hide_cpu = "";
    }

    $placeholders = array(
        'description' => _('Docker - Container CPU Usage'),
        'all' => array('warning' => "30", 'critical' => '50'),
        'networks' => array('warning' => array(), 'critical' => array()),
        'containers' => array('warning' => array(), 'critical' => array()),
        'timeout' => '0',
        'bad' => 'on',
        'percentage' => '',
        'networks-avg' => 'total',
        'aggregate' => "",
        'total' => "",
        'total-thresholds' => array('warning' => 50, 'critical' => 75),
        'avg' => 'on',
        'avg-thresholds' => array('warning' => 10, 'critical' => 20),
        'only' => '',
    );

    foreach ($placeholders as $index => $value) {
        if (!array_key_exists('cpu', $serviceargs) || !array_key_exists($index, $serviceargs['cpu'])) {
            $serviceargs['cpu'][$index] = $value;
        }
    }
?>
        <div id="configure-cpu" class="<?= $hide_cpu ?> col-sm-8 border-block mb-2">
            <h2 class="mb-2"><?= _('CPU Usage') ?></h2>

            <div id="cpu-all-table" class="all-table <?= $hide_all_table ?>">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-1">
                        <label for="count" class="form-check-label bold"><?= _('Per-Container Thresholds') ?> <?= xi6_info_tooltip(_('Each container found, will be checked against this threshold')) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" name="serviceargs[cpu][all][warning][]" id="serviceargs[cpu][all][warning][]" value="<?= encode_form_val($serviceargs['cpu']['all']['warning'][0]) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="serviceargs_cpu_all_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" name="serviceargs[cpu][all][critical][]" id="serviceargs[cpu][all][critical][]" value="<?= encode_form_val($serviceargs['cpu']['all']['critical'][0]) ?>" class="form-control form-control-sm monitor">
                            <span class="input-group-text">%</span>
                            <i id="serviceargs_cpu_all_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>

            <div id="cpu-network-table" class="network-table <?= $hide_networks_table ?> mb-3">
                <fieldset class="row g-2 pb-0">
                    <div class="form-check col-sm-4">
                        <label class="form-check-label bold"><?= _('Network Name/ID') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i><?= _('Critical') ?></label>
                    </div>
                </fieldset>
<?php 
    if (is_array($network_names)) {
        foreach($network_names as $index => $network) {
?>
                <fieldset class="row g-2 mt-1 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-0">
                        <input type="text" name="networknames[<?= $index ?>]" value="<?= encode_form_val($network) ?>" class="form-control form-control-sm" readonly>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[cpu][networks][warning][<?= $index ?>]" id="serviceargs[cpu][networks][warning][<?= $index ?>]" value="<?= encode_form_val($serviceargs['cpu']['networks']['warning'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_cpu_networks_warning_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[cpu][networks][critical][<?= $index ?>]" id="serviceargs[cpu][networks][critical][<?= $index ?>]" value="<?= encode_form_val($serviceargs['cpu']['networks']['critical'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_cpu_networks_critical_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
<?php 
        }
    }
?>
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <label for="serviceargs[cpu][networks-avg]" class="form-check-label bold"><?= _('Monitor Networks CPU usage by...') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group position-relative">
                            <select name="serviceargs[cpu][networks-avg]" id="serviceargs[cpu][networks-avg]" class="form-select form-select-sm form-control-sm monitor rounded">
                                <option value="total" <?= is_selected($serviceargs['cpu']['networks-avg'], 'total') ?>><?= _('total') ?></option>
                                <option value="average" <?= is_selected($serviceargs['cpu']['networks-avg'], 'average') ?>><?= _('average') ?></option>
                            </select>
                            <label for="serviceargs[cpu][networks-avg]" class="form-check-label bold ps-2 pt-1"><?= xi6_info_tooltip(_('Track the Networks CPU usage, by the total or average of its containers.')) ?></label>
                            <div class="invalid-feedback">
                                Please select network average or total CPU usage.
                            </div>
                            <i id="serviceargs_cpu_networks-avg_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

            </div> <!-- cpu-network-table -->

            <div id="cpu-container-table" class="container-table <?= $hide_containers_table ?> mb-3">
                <fieldset class="row g-2 pb-0">
                    <div class="form-check col-sm-4">
                        <label class="form-check-label bold"><?= _('Container Name/ID') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i></label>
                    </div>
                </fieldset>
<?php
    if (is_array($container_names)) {
        foreach($container_names as $index => $container) {
?>
                <fieldset class="row g-2 mt-1 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-0">
                        <input type="text" name="containernames[<?= $index ?>]" value="<?= encode_form_val($container) ?>" class="form-control form-control-sm" readonly>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[cpu][containers][warning][<?= $index ?>]" id="serviceargs[cpu][containers][warning][<?= $index ?>]" value="<?= encode_form_val($serviceargs['cpu']['containers']['warning'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_cpu_containers_warning_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[cpu][containers][critical][<?= $index ?>]" id="serviceargs[cpu][containers][critical][<?= $index ?>]" value="<?= encode_form_val($serviceargs['cpu']['containers']['critical'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_cpu_containers_critical_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
<?php 
        }
    }
?>
            </div> <!-- cpu-container-table -->

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[cpu][description]" class="form-check-label bold"><?= _('Service Description') ?> <?= xi6_info_tooltip(_('Warning: If you have another service with the same description, it will be overwritten by this service')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[cpu][description]" id="serviceargs[cpu][description]" value="<?= encode_form_val($serviceargs['cpu']['description']) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Service Description") ?>" >
                        <div class="invalid-feedback">
                            <?= _("Please enter the Service Description") ?>
                        </div>
                        <i id="serviceargs_cpu_description_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[cpu][timeout]" class="form-check-label bold"><?= _('Timeout') ?> <?= xi6_info_tooltip(_('Enter 0 to never time out the check')) ?></label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[cpu][timeout]" id="serviceargs[cpu][timeout]" value="<?= encode_form_val($serviceargs['cpu']['timeout']) ?>" class=" form-control form-control-sm monitor">
                        <span class="input-group-text"><?= _('sec') ?></span>
                        <i id="serviceargs_cpu_timeout_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="cpu-agg" class="form-check-input" name="serviceargs[cpu][aggregate]"  <?= is_checked($serviceargs['cpu']['aggregate']) ?> >
                    <label for="cpu-agg" class="form-check-label bold"><?= _('Use aggregate statistics') ?></label>
                </div>
            </fieldset>

            <div id="cpu-aggregate-options" class="row border-block ms-4 me-4 pt-2 pb-2 visually-hidden">
                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" class="form-check-input" id="cpu-total" name="serviceargs[cpu][total]" <?= is_checked($serviceargs['cpu']['total']) ?>>
                        <label for="cpu-total" class="form-check-label bold"><?= _('Check the total CPU usage') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" name="serviceargs[cpu][total-thresholds][warning]" id="serviceargs[cpu][total-thresholds][warning]" value="<?= encode_form_val($serviceargs['cpu']['total-thresholds']['warning']) ?>" class="textfield form-control condensed">
                            <i id="serviceargs_total_thresholds_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" name="serviceargs[cpu][total-thresholds][critical]" id="serviceargs[cpu][total-thresholds][critical]" value="<?= encode_form_val($serviceargs['cpu']['total-thresholds']['critical']) ?>" class="textfield form-control condensed">
                            <i id="serviceargs_total_thresholds_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" id="cpu-avg" class="form-check-input" name="serviceargs[cpu][avg]" <?= is_checked($serviceargs['cpu']['avg']) ?> >
                        <label for="cpu-avg" class="form-check-label bold"><?= _('Check the average (mean) CPU usage') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" id="serviceargs[cpu][avg-thresholds][warning]" name="serviceargs[cpu][avg-thresholds][warning]" value="<?= encode_form_val($serviceargs['cpu']['avg-thresholds']['warning']) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_cpu_avg_thresholds_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" name="serviceargs[cpu][avg-thresholds][critical]" id="serviceargs[cpu][avg-thresholds][critical]" value="<?= encode_form_val($serviceargs['cpu']['avg-thresholds']['critical']) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_avg_thresholds_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm mt-0">
                        <input type="checkbox" id="cpu-only" class="form-check-input" name="serviceargs[cpu][only]" <?= is_checked($serviceargs['cpu']['only']) ?>>
                        <label for="cpu-only" class="form-check-label bold"><?= _('Use only aggregate usage values (disables individual thresholds)') ?></label>
                    </div>
                </fieldset>

            </div> <!-- cpu-aggregate-options -->
        </div> <!-- configure-cpu -->

<?php 
    $hide_memory = "visually-hidden";

    if (array_key_exists("memory", $check_types)) {
        $hide_memory = "";
    }

    $placeholders = array(
        'description' => _('Docker - Container Memory Usage'),
        'all' => array('warning' => "30", 'critical' => '50'),
        'networks' => array('warning' => array(), 'critical' => array()),
        'containers' => array('warning' => array(), 'critical' => array()),
        'timeout' => '0',
        'bad' => 'on',
        'percentage' => '',
        'networks-avg' => 'total',
        'aggregate' => "",
        'total' => "",
        'total-thresholds' => array('warning' => 50, 'critical' => 75),
        'avg' => 'on',
        'avg-thresholds' => array('warning' => 10, 'critical' => 20),
        'only' => '',
    );

    foreach ($placeholders as $index => $value) {
        if (!array_key_exists('memory', $serviceargs) || !array_key_exists($index, $serviceargs['memory'])) {
            $serviceargs['memory'][$index] = $value;
        }
    }
?>
        <div id="configure-memory" class="<?= $hide_memory ?> col-sm-8 border-block mb-2">
            <h2 class="mb-2"><?= _('Memory Usage') ?></h2>

            <div id="memory-all-table" class="all-table <?= $hide_all_table ?>">
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-3 mt-0 pt-1">
                        <label for="count" class="form-check-label bold"><?= _('Per-Container Thresholds') ?> <?= xi6_info_tooltip(_('Each container found, will be checked against this threshold')) ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" id="serviceargs[memory][all][warning][]" name="serviceargs[memory][all][warning][]" value="<?= encode_form_val($serviceargs['memory']['all']['warning'][0]) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_memory_all_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" id="serviceargs[memory][all][critical][]" name="serviceargs[memory][all][critical][]" value="<?= encode_form_val($serviceargs['memory']['all']['critical'][0]) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_memory_all_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
            </div>

            <div id="memory-network-table" class="network-table <?= $hide_networks_table ?> mb-3">
                <fieldset class="row g-2 pb-0">
                    <div class="form-check col-sm-4">
                        <label class="form-check-label bold"><?= _('Network Name/ID') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i></label>
                    </div>
                </fieldset>
<?php
    if (is_array($network_names)) {
        foreach($network_names as $index => $network) {
?>
                <fieldset class="row g-2 mt-1 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-0">
                        <input type="text" name="networknames[<?= $index ?>]" value="<?= encode_form_val($network) ?>" class="form-control form-control-sm" readonly>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[memory][networks][warning][<?= $index ?>]" id="serviceargs[memory][networks][warning][<?= $index ?>]" value="<?= encode_form_val($serviceargs['memory']['networks']['warning'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_memory_networks_warning_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[memory][networks][critical][<?= $index ?>]" id="serviceargs[memory][networks][critical][<?= $index ?>]" value="<?= encode_form_val($serviceargs['memory']['networks']['critical'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_memory_networks_critical_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
<?php
        }
    }
?>
                <fieldset class="row g-2 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <label for="serviceargs[memory][networks-avg]" class="form-check-label bold"><?= _('Monitor Networks Memory usage by...') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group position-relative">
                            <select name="serviceargs[memory][networks-avg]" id="serviceargs[memory][networks-avg]" class="form-select form-select-sm form-control-sm monitor rounded">
                                <option value="total" <?= is_selected($serviceargs['memory']['networks-avg'], 'total') ?>><?= _('total') ?></option>
                                <option value="average" <?= is_selected($serviceargs['memory']['networks-avg'], 'average') ?>><?= _('average') ?></option>
                            </select>
                            <label for="serviceargs[memory][networks-avg]" class="form-check-label bold ps-2 pt-1"><?= xi6_info_tooltip(_('Track the Networks memory usage, by the total or average of its containers.')) ?></label>
                            <div class="invalid-feedback">
                                Please select network average or total memory.
                            </div>
                            <i id="percentage_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

            </div> <!-- memory-network-table -->

            <div id="memory-container-table" class="container-table <?= $hide_containers_table ?> mb-3">
                <fieldset class="row g-2 pb-0">
                    <div class="form-check col-sm-4">
                        <label class="form-check-label bold"><?= _('Container Name/ID') ?></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i></label>
                    </div>
                    <div class="col-sm-3">
                        <label class="form-check-label bold"><i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i></label>
                    </div>
                </fieldset>
<?php
    if (is_array($container_names)) {
        foreach($container_names as $index => $container) {
?>
                <fieldset class="row g-2 mt-1 mb-1 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-0">
                        <input type="text" name="containernames[<?= $index ?>]" value="<?= encode_form_val($container) ?>" class="form-control form-control-sm" readonly>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[memory][containers][warning][<?= $index ?>]" id="serviceargs[memory][containers][warning][<?= $index ?>]" value="<?= encode_form_val($serviceargs['memory']['containers']['warning'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_memory_containers_warning_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <input type="text" name="serviceargs[memory][containers][critical][<?= $index ?>]" id="serviceargs[memory][containers][critical][<?= $index ?>]" value="<?= encode_form_val($serviceargs['memory']['containers']['critical'][$index]) ?>" class="form-control form-control-sm monitor threshold">
                            <i id="serviceargs_memory_containers_critical_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>
<?php
        }
    }
?>
            </div> <!-- memory-container-table -->

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[memory][description]" class="form-check-label bold"><?= _('Service Description') ?> <?= xi6_info_tooltip(_('Warning: If you have another service with the same description, it will be overwritten by this service')) ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[memory][description]" id="serviceargs[memory][description]" value="<?= encode_form_val($serviceargs['memory']['description']) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Service Description") ?>" >
                        <div class="invalid-feedback">
                            <?= _("Please enter the Service Description") ?>
                        </div>
                        <i id="serviceargs_memory_description_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="serviceargs[memory][timeout]" class="form-check-label bold"><?= _('Timeout') ?> <?= xi6_info_tooltip(_('Enter 0 to never time out the check')) ?></label>
                </div>
                <div class="col-sm-3 mt-0">
                    <div class="input-group input-group-sm">
                        <input type="text" name="serviceargs[memory][timeout]" id="serviceargs[memory][timeout]" value="<?= encode_form_val($serviceargs['memory']['timeout']) ?>" class=" form-control form-control-sm monitor">
                        <span class="input-group-text"><?= _('sec') ?></span>
                        <i id="serviceargs_memory_timeout_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm-3 mt-0 pt-1">
                    <label for="percentage" class="form-check-label bold"><?= _('Express container memory usage') ?></label>
                </div>
                <div class="col-sm-6 mt-0">
                    <div class="input-group position-relative">
                        <select name="serviceargs[memory][percentage]" id="percentage" class="form-select form-select-sm form-control-sm monitor rounded">
                            <option value="bytes" <?= is_selected($serviceargs['memory']['percentage'], 'bytes') ?>><?= _('in bytes ') ?></option>
                            <option value="kibibytes" <?= is_selected($serviceargs['memory']['percentage'], 'kibibytes') ?>><?= _('in KiB ') ?></option>
                            <option value="mebibytes" <?= is_selected($serviceargs['memory']['percentage'], 'mebibytes') ?>><?= _('in MiB ') ?></option>
                            <option value="gibibytes" <?= is_selected($serviceargs['memory']['percentage'], 'gibibytes') ?>><?= _('in GiB ') ?></option>
                            <option value="percentage" <?= is_selected($serviceargs['memory']['percentage'], 'percentage') ?>><?= _('as a percent of its limit') ?></option>
                        </select>
                        <div class="invalid-feedback">
                            Please select memory percentage measurement.
                        </div>
                        <i id="percentage_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </fieldset>

            <fieldset class="row g-2 mb-1 wz-fieldset">
                <div class="form-check col-sm mt-0">
                    <input type="checkbox" id="memory-agg" class="form-check-input" name="serviceargs[memory][aggregate]"  <?= is_checked($serviceargs['memory']['aggregate']) ?> >
                    <label for="memory-agg" class="form-check-label bold"><?= _('Use aggregate statistics') ?></label>
                </div>
            </fieldset>

            <div id="memory-aggregate-options" class="row border-block ms-4 me-4 pt-2 pb-2 visually-hidden">
                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" class="form-check-input" id="memory-total" name="serviceargs[memory][total]" <?= is_checked($serviceargs['memory']['total']) ?>>
                        <label for="memory-total" class="form-check-label bold"><?= _('Check the total memory usage') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" name="serviceargs[memory][total-thresholds][warning]" id="serviceargs[memory][total-thresholds][warning]" value="<?= encode_form_val($serviceargs['memory']['total-thresholds']['warning']) ?>" class="textfield form-control condensed">
                            <i id="serviceargs_total_thresholds_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" name="serviceargs[memory][total-thresholds][critical]" id="serviceargs[memory][total-thresholds][critical]" value="<?= encode_form_val($serviceargs['memory']['total-thresholds']['critical']) ?>" class="textfield form-control condensed">
                            <i id="serviceargs_total_thresholds_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm-4 mt-0 pt-1">
                        <input type="checkbox" id="memory-avg" class="form-check-input" name="serviceargs[memory][avg]" <?= is_checked($serviceargs['memory']['avg']) ?> >
                        <label for="memory-avg" class="form-check-label bold"><?= _('Check the average (mean) memory usage') ?></label>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                            </span>
                            <input type="text" id="serviceargs[memory][avg-thresholds][warning]" name="serviceargs[memory][avg-thresholds][warning]" value="<?= encode_form_val($serviceargs['memory']['avg-thresholds']['warning']) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_memory_avg_thresholds_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-0">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">
                                <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                            </span>
                            <input type="text" name="serviceargs[memory][avg-thresholds][critical]" id="serviceargs[memory][avg-thresholds][critical]" value="<?= encode_form_val($serviceargs['memory']['avg-thresholds']['critical']) ?>" class="form-control form-control-sm monitor">
                            <i id="serviceargs_avg_thresholds_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </fieldset>

                <fieldset class="row g-2 mt-0 mb-0 wz-fieldset">
                    <div class="form-check col-sm mt-0">
                        <input type="checkbox" id="memory-only" class="form-check-input" name="serviceargs[memory][only]" <?= is_checked($serviceargs['memory']['only']) ?>>
                        <label for="memory-only" class="form-check-label bold"><?= _('Use only aggregate usage values (disables individual thresholds)') ?></label>
                    </div>
                </fieldset>

            </div> <!-- memory-aggregate-options -->
        </div> <!-- configure-memory -->

    </div> <!-- container -->

    <script type="text/javascript">
        $(document).ready(function () {
            if ($("#cpu-agg").prop("checked")) {
                $("#cpu-aggregate-options").removeClass('visually-hidden');
            }

            if ($("#cpu-only").prop("checked")) {
                //$("#cpu-container-table > table > tbody > tr > td:not(:first-child)").children().prop("disabled", true);
                //$("#cpu-network-table > table > tbody > tr > td:not(:first-child)").children().prop("disabled", true);
                $("#cpu-container-table").find("input.threshold").prop("disabled", true);
                $("#cpu-network-table").find("input.threshold").prop("disabled", true);
            }

            if ($("#memory-agg").prop("checked")) {
                $("#memory-aggregate-options").removeClass('visually-hidden');
            }

            if ($("#memory-only").prop("checked")) {
                $("#memory-container-table").find("input.threshold").prop("disabled", true);
                $("#memory-network-table").find("input.threshold").prop("disabled", true);
            }
        });

        $("#cpu-agg").on("click", function () {
            if ($(this).prop("checked")) {
                $("#cpu-aggregate-options").removeClass('visually-hidden');
            } else {
                $("#cpu-aggregate-options").addClass('visually-hidden');
            }
        });

        $("#cpu-only").on("click", function () {
            if ($("#cpu-only").prop("checked")) {
                $("#cpu-container-table").find("input.threshold").prop("disabled", true);
                $("#cpu-network-table").find("input.threshold").prop("disabled", true);
            } else {
                $("#cpu-container-table").find("input.threshold").prop("disabled", false);
                $("#cpu-network-table").find("input.threshold").prop("disabled", false);
            }
        });

        $("#memory-agg").on("click", function () {
            if ($(this).prop("checked")) {
                $("#memory-aggregate-options").removeClass('visually-hidden');
            } else {
                $("#memory-aggregate-options").addClass('visually-hidden');
            }
        });

        $("#memory-only").on("click", function () {
            if ($("#memory-only").prop("checked")) {
                $("#memory-container-table").find("input.threshold").prop("disabled", true);
                $("#memory-network-table").find("input.threshold").prop("disabled", true);
            } else {
                $("#memory-container-table").find("input.threshold").prop("disabled", false);
                $("#memory-network-table").find("input.threshold").prop("disabled", false);
            }
        });
    </script>

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
