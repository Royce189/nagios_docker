    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>" />
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <h2 class="mb-2"><?= _('Docker Server Information') ?></h2>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="remote" class="form-label form-item-required"><?= _('Access Docker via') ?>  </label>
                    <div class="input-group position-relative">
                        <select name="remote" id="remote" class="form-select monitor rounded" placeholder="<?= _("Choose Docker access via... ") ?> " required>
                            <option value="NCPA" <?= is_selected($remote, "NCPA");?>><?= _('Remote Agent (NCPA)') ?></option>
                            <option value="api" <?= is_selected($remote, "api");?>><?= _('Remote API') ?></option>
                        </select>
                        <div class="invalid-feedback">
                            Please select Access Docker via
                        </div>
                        <i id="remote_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="ip_address" class="form-label form-item-required"><?= _('IP Address') ?> <?= xi6_info_tooltip(_('The IP address or FQDN of the server you would like to monitor')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="ip_address" id="ip_address" value="<?= $address ?>" class="form-control monitor rounded" placeholder="<?= _("Enter IP Address") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the IP Address
                        </div>
                        <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2 ncpa-only">
                <div class="col-sm-6">
                    <label for="port" class="form-label form-item-required"><?= _("NCPA Listener Port") ?> </label>
                    <div class="input-group position-relative">
                        <input type="text" name="port" id="port" value="<?= $port ?>" class="form-control monitor rounded" placeholder="<?= _("Enter NCPA Listener Port") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the NCPA Listener Port
                        </div>
                        <i id="port_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2 ncpa-only">
                <div class="col-sm-6">
                    <label for="token" class="form-label form-item-required"><?= _("NCPA Token") ?> </label>
                    <div class="input-group position-relative">
                        <input type="text" name="token" id="token" value="<?= encode_form_val($token) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter NCPA Token") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the NCPA Token
                        </div>
                        <i id="token_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2 ncpa-only">
                <div class="col-sm-6">
                    <label for="socket" class="form-label form-item-required">
                        <?= _('Docker Socket') ?>
                        <?= xi6_info_tooltip(_('The full path to your docker socket').'.  Ex: /var/run/docker.sock') ?>
                    </label>
                    <div class="input-group position-relative">
                        <input type="text" name="socket" id="socket" value="<?= $socket ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Docker Socket") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the Docker Socket
                        </div>
                        <i id="socket_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="baseurl" class="form-label form-item-required">
                        <?= _('Docker API Base URL') ?>
                         <?= xi6_info_tooltip(_('The full URL to your Docker API').'.  Ex: http:/v1.30/ or http://192.168.1.2:2375/') ?>
                    </label>
                    <div class="input-group position-relative">
                        <input type="text" name="baseurl" id="baseurl" value="<?= $baseurl ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Docker API Base URL") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the Docker API Base URL
                        </div>
                        <i id="baseurl_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div id="security" class="visually-hidden">
                <h2 class="mt-4"><?= _('Security') ?></h2>
                <?= _('This section is only needed when using the remote API and have protected your Docker port using TLS') ?>

                <div class="row mb-2">
                    <div class="col-sm-6">
                        <label for="cert" class="form-label"><?= _('Certificate') ?> <?= xi6_info_tooltip(_('The path to your certificate')) ?></label>
                        <div class="input-group position-relative">
                            <input type="text" name="cert" id="cert" value="<?= $cert ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Certificate") ?>">
                            <div class="invalid-feedback">
                                Please enter the Certificate
                            </div>
                            <i id="cert_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-sm-6">
                        <label for="key" class="form-label"><?= _('Key') ?> <?= xi6_info_tooltip(_('The path to your key')) ?></label>
                        <div class="input-group position-relative">
                            <input type="text" name="key" id="key" value="<?= $key ?>" class="form-control monitor rounded" placeholder="<?= _("Enter Key") ?>">
                            <div class="invalid-feedback">
                                Please enter the Key
                            </div>
                            <i id="key_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-sm-6">
                        <label for="cacert" class="form-label"><?= _('CA Certification') ?> <?= xi6_info_tooltip(_('The path to your CA certificate')) ?></label>
                        <div class="input-group position-relative">
                            <input type="text" name="cacert" id="cacert" value="<?= $cacert ?>" class="form-control monitor rounded" placeholder="<?= _("Enter CA Certification") ?>">
                            <div class="invalid-feedback">
                                Please enter the CA Certification
                            </div>
                            <i id="cacert_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                        </div>
                    </div>
                </div>
            </div>

            <h2 class="mt-4"><label class="form-item-required"><?= _('Checks to run') ?></label></h2>
            <?= _('These checks can be configured on the next page') ?>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id=containers_exist_box class="form-check-input mt-1 me-2" name="checktype[exist]" <?= is_checked(checkbox_binary($check_types["exist"]), "1") ?>>
                    <label for="containers_exist_box" class="form-check-label"><?= _('Existing Containers') ?></label>
                </div>
            </div>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id=containers_running_box class="form-check-input mt-1 me-2" name="checktype[running]" <?= is_checked(checkbox_binary($check_types["running"]), "1") ?>>
                    <label for="containers_running_box" class="form-check-label"><?= _('Running Containers') ?></label>
                </div>
            </div>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id=containers_healthy_box class="form-check-input mt-1 me-2" name="checktype[healthy]" <?= is_checked(checkbox_binary($check_types["healthy"]), "1") ?>>
                    <label for="containers_healthy_box" class="form-check-label"><?= _('Healthy Containers') ?></label>
                </div>
            </div>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id=containers_cpu_box class="form-check-input mt-1 me-2" name="checktype[cpu]" <?= is_checked(checkbox_binary($check_types["cpu"]), "1") ?>>
                    <label for="containers_cpu_box" class="form-check-label"><?= _('CPU Usage') ?></label>
                </div>
            </div>

            <div class="row mb-3 mt-4">
                <div class="col-sm">
                    <input type="checkbox" id=containers_memory_box class="form-check-input mt-1 me-2" name="checktype[memory]" <?= is_checked(checkbox_binary($check_types["memory"]), "1") ?>>
                    <label for="containers_memory_box" class="form-check-label"><?= _('Memory Usage') ?></label>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="list-type" class="form-label form-item-required"><?= _('Monitoring Method') ?> </label>
                    <div class="input-group position-relative">
                        <select name="list-type" id="list-type" class="form-select monitor rounded" placeholder="<?= _("Select Monitor Method") ?> " required>
                            <option value="none" <?= is_selected($list_type, "none") ?> disabled selected hidden>Choose a Monitoring Method...</option>
                            <option value="containers" <?= is_selected($list_type, "containers") ?>><?= _('A list of containers') ?></option>
                            <option value="networks" <?= is_selected($list_type, "networks") ?>><?= _('The containers on a list of networks') ?></option>
                            <option value="all" <?= is_selected($list_type, "all") ?>><?= _('All visible containers') ?></option>
                        </select>
                        <div class="invalid-feedback">
                            Please select Monitor Method
                        </div>
                        <i id="list-type_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div id="populate-tables" name="populate-tables" class="row mb-2 visually-hidden">
                <div class="col-sm-auto">
                    <button type="button" class="btn btn-sm btn-primary"><?= _("Populate List") ?></button>
                </div>
            </div>
<?php 
    if (is_array($container_names)) {
?>
            <div id="container-table" class="container-table visually-hidden">
                <div class="col-sm-6 border-block ms-2">
                    <label class="form-label form-item-required"><?= _('Container Name/IDs') ?></label>
<?php
        $count = 0;

        foreach($container_names as $index => $container) {
?>
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="containernames[<?= $index ?>]" id="containernames[<?= $index ?>]" value="<?= encode_form_val($container) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="containernames_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
            $count++;
        } 

        if (empty($container_names)) {
?>
                    <!-- Initial Row -->
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="containernames[<?= count($container_names) ?>]" id="containernames[<?= count($container_names) ?>]" value="" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="containernames_<?= count($container_names) ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
        }
    } else {
?>
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="containernames[0]" id="containernames[0]" value="" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="containernames_0_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
    }
?>
                    <div class="mt-2 add-row-containers">
                        <label class="form-label">
                            <a style="cursor: pointer;" id="add-row-containers" name="add-row-containers" class="btn btn-link"><i class="fa fa-plus"></i> <?= _('Add Row') ?></a>
                            <?= xi6_info_tooltip(_('Add another row.')) ?>
                        </label>
                    </div>
                </div> <!-- border-block -->
            </div>  <!-- container-table -->
<?php 
    if (is_array($network_names)) {
?>
            <div id="network-table" class="network-table visually-hidden">
                <div class="col-sm-6 border-block ms-2">
                    <label class="form-label form-item-required"><?= _('Network Name/IDs') ?></label>
<?php
        $count = 0;

        foreach($network_names as $index => $network) {
?>
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="networknames[<?= $index ?>]" id="networknames[<?= $index ?>]" value="<?= encode_form_val($network) ?>" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="networknames_<?= $index ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
            $count++;
        } 

        if (empty($network_names)) {
?>
                    <!-- Initial Row -->
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="networknames[<?= count($network_names) ?>]" id="networknames[<?= count($network_names) ?>]" value="" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="networknames_<?= count($network_names) ?>_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
        }
    } else {
?>
                    <div class="row mb-2">
                        <div class="col-sm">
                            <div class="input-group position-relative">
                                <input type="text" name="networknames[0]" id="networknames[0]" value="" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>">
                                <i id="networknames_0_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                            </div>
                        </div>
                    </div>
<?php
    }
?>
                    <div class="mt-2 add-row-networks">
                        <label class="form-label">
                            <a style="cursor: pointer;" id="add-row-networks" name="add-row-networks" class="btn btn-link"><i class="fa fa-plus"></i> <?= _('Add Row') ?></a>
                            <?= xi6_info_tooltip(_('Add another row.')) ?>
                        </label>
                    </div>

                </div> <!-- border-block -->
            </div>  <!-- network-table -->
        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>

    <script type="text/javascript">
        var canPopulateTables = false;
        var rownumContainers = 0;
        var rownumNetworks = 0;

        $(document).ready(function () {

            function add_row(obj, value = '') {
                var tableName = "containernames";
                var type = "containers";
                var table = $(obj).closest("[id$='-table']")
                var tableType = $(table)[0]

                var rownum = rownumContainers;

                tableTypeId = tableType.id;

                if (tableTypeId === "network-table") {
                    tableName = "networknames"
                    type = "networks";

                    rownum = rownumNetworks;
                }

                rownum++;

                if (type == "networks") {
                    // Update "global" variable.
                    rownumNetworks = rownum;
                } else {
                    // Update "global" variable.
                    rownumContainers = rownum;
                }

                row = "".concat(
'                <div class="row mb-2">',
'                    <div class="col-sm">',
'                        <div class="input-group position-relative">',
'                            <input type="text" name="'+tableName+'['+rownum+']" id="'+tableName+'['+rownum+']" value="'+value+'" class="form-control monitor rounded" placeholder="<?= _("Enter ") ?>"',
'                            <i id="'+tableName+'_'+rownum+'_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>',
'                        </div>',
'                    </div>',
'                </div>',
    );

                var endOfList = $("#"+tableTypeId).find(".add-row-"+type);
                $(row).insertBefore(endOfList);
            }

            $("#list-type").change(function() {
                var table = "container-table";
                var type = "containers";
                var rownum = rownumContainers;

                $("#network-table").addClass('visually-hidden');
                $("#container-table").addClass('visually-hidden');
                $("#populate-tables").addClass('visually-hidden');

                if ($(this).val() === "networks") {
                    table = "network-table";
                    type = "networks";
                    rownum = rownumNetworks;

                    $("#network-table").removeClass('visually-hidden');

                    if (canPopulateTables) {
                        $("#populate-tables").removeClass('visually-hidden');
                    }
                } else if ($(this).val() === "containers") {
                    $("#container-table").removeClass('visually-hidden');

                    if (canPopulateTables) {
                        $("#populate-tables").removeClass('visually-hidden');
                    }
                }

                // Bind click action to add-row button.
                $(document).on('click', '#add-row-'+type, function() { add_row(this); });

                // Scroll the "table" into view.
                document.getElementsByClassName('add-row-'+type)[0].scrollIntoView({ behavior: "smooth" });
            });

            $("#remote").change(function () {
                canPopulateTables = false;

                if ($(this).val() === "api") {
                    // using tcp-bound API directly.
                    $("#security").removeClass('visually-hidden');
                    $(".ncpa-only").addClass('visually-hidden');
                    $("#port").removeAttr('required');
                    $("#token").removeAttr('required');
                    $("#socket").removeAttr('required');

                    if ($("list-type").val() === "networks" || $("#list-type").val() === "containers") {
                        $("#populate-tables").removeClass('visually-hidden');
                    }

                    canPopulateTables = true;

                } else {
                    // using NCPA
                    $(".ncpa-only").removeClass('visually-hidden');
                    $("#port").attr('required');
                    $("#token").attr('required');
                    $("#socket").attr('required');
                    $("#security").addClass('visually-hidden');
                    $("#populate-tables").addClass('visually-hidden');
                }
            });

            // Initialize
            if ($("#remote").val() === "api") {
                $(".ncpa-only").addClass('visually-hidden');
                $("#port").removeAttr('required');
                $("#token").removeAttr('required');
                $("#socket").removeAttr('required');
                $("#security").removeClass('visually-hidden');
                $("#network-table").addClass('visually-hidden');
                $("#container-table").addClass('visually-hidden');
                $("#populate-tables").addClass('visually-hidden');

                canPopulateTables = true;
            } else {
                // using NCPA
                $(".ncpa-only").removeClass('visually-hidden');
                $("#port").attr('required');
                $("#token").attr('required');
                $("#socket").attr('required');
                $("#security").addClass('visually-hidden');
                $("#network-table").addClass('visually-hidden');
                $("#container-table").addClass('visually-hidden');
                $("#populate-tables").addClass('visually-hidden');
            }

            // Initialize - If we have data (step2)
            // NOTE: Must be after the "other" Initialize block.
            if ($("#list-type").val() === "networks") {
                $("#network-table").removeClass('visually-hidden');

                if (canPopulateTables) {
                    $("#populate-tables").removeClass('visually-hidden');
                }

            } else if ($("#list-type").val() === "containers") {
                $("#container-table").removeClass('visually-hidden');

                if (canPopulateTables) {
                    $("#populate-tables").removeClass('visually-hidden');
                }
            }

            // Table population AJAX/modal
            $("#populate-tables").click(function() {
                display_child_popup(300);
                center_child_popup();

                var popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Please Wait") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'        <li class="commandresultwaiting" id="populate-tables-command-result">',
'            <?= _("Populating tables...") ?> (0/2)',
'        </li>',
'    </ul>',
'</div>'
                    );

                set_child_popup_content(popup_content);

                // We are in nagiosxi/config/monitoringwizard.php, need to be in nagiosxi/includes/configwizards/docker/table_population.php

                base_url = "../includes/configwizards/docker/table_population.php";

                var containers_array = {};
                containers_array["cert"] = $("#cert").val();
                containers_array["key"] = $("#key").val();
                containers_array["cacert"] = $("#cacert").val();
                containers_array["host"] = $("#baseurl").val();
                containers_array["mode"] = "containers";

                var networks_array = $.extend({}, containers_array);
                networks_array["mode"] = "networks";

                var global_result = 2;

                var postingNetworks = $.post(base_url, networks_array);
                postingNetworks.done(function(data) {
                    var result = table_inject('network-table', $.parseJSON(data));
                    mod_global_result(result);
                    display_result(data);
                });

                var postingContainer = $.post(base_url, containers_array);
                postingContainer.done(function(data) {
                    var result = table_inject('container-table', $.parseJSON(data));
                    mod_global_result(result);
                    display_result(data);
                });

                function mod_global_result(result) {
                    if (result === 0) {
                        if (global_result > 0) {
                            global_result -= 1;
                        }
                    } else {
                        global_result = result;
                    }
                }

                function display_result(data) {
                    switch (global_result) {
                        case -3:
                            popup_content = "".concat(
'<div id="popup_header">',
'   <b><?= _("Error") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'        <li class="commandresulterror" id="populate-tables-command-result">',
'            <?= _("cURL was called on an incorrect endpoint.") ?>',
'        </li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            break;

                        case -2:
                            popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Error") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'        <li class="commandresulterror" id="populate-tables-command-result"><?= _("cURL call did not get a valid response from the listed address.") ?></li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            break;

                        case -1:
                            popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Error") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'         <li class="commandresulterror" id="populate-tables-command-result"><?= _("Please put a valid URL in the cell labelled \"Docker API Base URL\".") ?></li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            break;

                        case 0:
                            popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Success!") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'        <li class="commandresultok" id="populate-tables-command-result"><?= _("Successfully loaded!") ?></li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            fade_child_popup("green", 3000);
                            break;

                        case 1:
                            popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Please Wait...") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'        <li class="commandresultwaiting" id="populate-tables-command-result"><?= _("Populating...") ?> (1/2)</li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            break;

                        default:
                            popup_content = "".concat(
'<div id="popup_header">',
'    <b><?= _("Please Wait...") ?></b>',
'</div>',
'<div id="popup_data">',
'    <p></p>',
'    <ul class="ajaxcommandresult">',
'         <li class="commandresultwaiting" id="populate-tables-command-result"><?= _("Populating...") ?> (0/2)</li>',
'    </ul>',
'</div>'
                                );
                            set_child_popup_content(popup_content);
                            break;
                    }
                }
            });

            function table_inject(which_one, data) {
                if (data === "error_host") {
                    return -1;
                } else if (data === "error_curl") {
                    return -2;
                } else if ("message" in data) {
                    return -3;
                }

                var arr_name = "networknames";
                var type = "networks";
                var rownum = rownumNetworks;

                if (which_one === "container-table") {
                    arr_name = "containernames";
                    type = "containers";
                    rownum = rownumContainers;
                }

                // Reinitializes x, between calls (container and network). Shouldn't be necessary, but it is.
                var x = 0;

                for (x in data) {
                    // Remember, dynamically created elements!
                    var which_input = $("#"+which_one).find("input[name='"+arr_name+"["+x+"]']");

                    // Length is 0, for "null" elements.
                    if (which_input.length == 0) {
                        // Add a row
                        add_row($("#"+which_one).find("#add-row-"+type), data[x]);

                        // Find the input element, now that it has been created.
                        which_input = $("#"+which_one).find("input[name='"+arr_name+"["+x+"]']");

                        // Bring the whole table into view.
                        document.getElementsByClassName('add-row-'+type)[0].scrollIntoView({ behavior: "smooth" });
                    } else {

                        // Insert the data into the text field.
                        $(which_input).val(data[x]);
                    }
                }

                return 0;
            }
        });
    </script>
