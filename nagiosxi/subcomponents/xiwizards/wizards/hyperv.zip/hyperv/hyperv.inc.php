<?php
//
// HyperV Config Wizard
// Copyright (c) 2019-2024 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

hyperv_configwizard_init();

function hyperv_configwizard_init()
{
    $name = 'hyperv';
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _('Monitor your Hyper-V server via NCPA.'),
        CONFIGWIZARD_DISPLAYTITLE => _('Hyper-V'),
        CONFIGWIZARD_FUNCTION => 'hyperv_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'hyperv.png',
        CONFIGWIZARD_VERSION => '2.0.2',
        CONFIGWIZARD_COPYRIGHT => _("Copyright &copy; 2019-2024 Nagios Enterprises, LLC."),
        CONFIGWIZARD_AUTHOR => _('Nagios Enterprises, LLC.'),
        CONFIGWIZARD_FILTER_GROUPS => array('server'),
        CONFIGWIZARD_REQUIRES_VERSION => 60100
    );
    register_configwizard($name, $args);
}

/* This function is automatically called by the XI wizard framework when the wizard is run */
function hyperv_configwizard_func($mode = '', $inargs = null, &$outargs = null, &$result = null)
{
    $wizard_name = 'hyperv';

    /* Prerequisite software */
    $NCPA_download_url = "https://www.nagios.org/ncpa/#downloads";
    $NCPA_docs_url = "https://www.nagios.org/ncpa/#docs";

    /* Initialize return code and output */
    $result = 0;
    $output = '';

    /* Initialize output args */
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            // Allow debugging before proper output starts
            $output = '';

            /* This defines $nextstep variable, used for determining if the user did not */
            /* provide correct information when the user was on CONFIGWIZARD_MODE_GETSTAGE1HTML */
            $nextstep = encode_form_val(grab_array_var($_POST, 'nextstep', false), ENT_QUOTES);

            /* Determine if this is the first wizard run */
            if ($nextstep == '') {
                /* Clear the session array to be sure it is blank */
                unset($_SESSION[$wizard_name]);
            }

            if (!isset($_POST['ip_address'])) {
                /* Fresh Wizard Run */
                /* Define the session array to hold data from different stages */
                $_SESSION[$wizard_name] = array();

                // NCPA Stuff
                $address = '';
                $port = '5693';
                $token = '';

            } else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */
                $address_session = grab_array_var($_SESSION[$wizard_name],'ip_address','');
                $address = grab_array_var($inargs,'ip_address', $address_session);
                $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '5693');
                $port = grab_array_var($inargs, 'port', $port_session);
                $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
                $token = grab_array_var($inargs, 'token', $token_session);
            }

            # Get the existing host/node configurations.
            # TODO: Include passwords/secrets?
            $nodes = get_configwizard_hosts($wizard_name);

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step1 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step1.php';
            $output = ob_get_clean();

            break;


        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE1HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE2HTML */
            $back = array_key_exists("backButton", $_POST);

            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) {
                break;
            }

            /* Get variables that were passed to us */
            $address_session = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            $address = grab_array_var($inargs,'ip_address',$address_session);
            $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $port = grab_array_var($inargs, 'port', $port_session);
            $port = intval($port);
            $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
            $token = grab_array_var($inargs, 'token', $token_session);

            /* Start actual validation */
            $errors = 0;
            $errmsg = array();

            if ($address === "debugging" && $token === "debugging") {
                $_SESSION[$wizard_name]['ip_address'] = $address;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
                break;
            }

            if (have_value($address) == false) {
                /* address field was blank, add an error message to the array and increment the $errors count */
                $errmsg[$errors++] = _('No address specified.');
            }

            $ncpa_full_url = "https://" . $address . ":" . $port . "/api/windowscounters/Hyper-V%20Hypervisor%20Logical%20Processor(_Total)/%25%20Total%20Run%20Time?sleep=1&token=" . $token;
            $cmd = '';
            $result = hyperv_ncpa_installed_check($ncpa_full_url, $cmd); // defined at end of file

            if ($result > 0) {
                if ($result == 1) {
                    $errmsg[$errors++] = _("cURL call to verify NCPA installation failed.");
                } else if ($result == 2) {
                    $errmsg[$errors++] = _("NCPA port did not return JSON data.");
                } else if ($result == 3) {
                    $errmsg[$errors++] = _("NCPA on this server does not support 'windowscounters.");
                } else if ($result == 4) {
                    $errmsg[$errors++] = _("Hyper-V performance counters not installed on remote machine.");
                } else {
                    $errmsg[$errors++] = sprintf(_("cURL-related error: %s"), "$result");
                }
            }

            /* Check to see if the $errors array contains errors */
            if ($errors>0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            } else {
                $_SESSION[$wizard_name]['ip_address'] = $address;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE1DATA */
            break;



        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE3HTML */
            $back = encode_form_val(grab_array_var($_POST,'backButton',false),ENT_QUOTES);

            if (isset($_POST['ip_address'])) {
                /* Continuing from CONFIGWIZARD_MODE_GETSTAGE1HTML */

                /* Grab array variables from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                $address = $_SESSION[$wizard_name]['ip_address'];

                /* The following function queries DNS using $addess to see if it can determine a FQDN for the object */
                $hostname = gethostbyaddr($address);

            } else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE2DATA due to user error */

                $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', '');
                $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

                $address = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            }

            // Pull Old variables from $_SESSION. These should not change for the rest of the wizard, so logic is performed outside of any conditionals.
            $port = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $token = grab_array_var($_SESSION[$wizard_name], 'token', '');

            // New variable. This should also just kinda work.
            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step2 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step2.php';
            $output = ob_get_clean();

            break;

        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE2HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            $back = array_key_exists("backButton", $_POST);
            if ($back) break;

            $hostname_session = grab_array_var($_SESSION, 'hostname', '');
            $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
            $serviceargs = grab_array_var($inargs, 'serviceargs', $serviceargs);

            if (!have_value($hostname)) {
                $errmsg[$errors++] = _("No host name specified.");
            }
            else if (!is_valid_host_name($hostname)) {
                $errmsg[$errors++] = _("Invalid host name.");
            }

            $_SESSION[$wizard_name]['hostname'] = $hostname;

            if (empty($serviceargs)) {
                $errmsg[$errors++] = _("serviceargs is empty. This error should never be reached. Please contact the config wizard maintainer.");
            }

            foreach ($serviceargs as $section) {

                foreach ($section as $check) {

                    $endpoint = $check['object'] . (isset($check['object']) ? "({$check['instance']})" : '') . "\\{$check['counter']}";
                    if (isset($check['on']) && isset($check['invalid'])) {
                        $errmsg[$errors++] = sprintf(_("Windows Performance Counter %s could not be found."), $endpoint);
                    }
                }
            }

            if ($errors > 0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
                if (!array_key_exists('serviceargs', $_SESSION[$wizard_name])) {
                    // If we've never assigned serviceargs to SESSION, it's fine to overwrite even if they're not valid.
                    $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                }
            }
            else {
                $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE2DATA */
            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $back = array_key_exists('backButton', $_POST);


            $output = '
            ';
            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE3HTML */
            break;


        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $back = array_key_exists("backButton", $_POST);
            if ($back) {
                break;
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '';
            break;


        case CONFIGWIZARD_MODE_GETOBJECTS:
            $address = $_SESSION[$wizard_name]['ip_address'];
            $hostname = $_SESSION[$wizard_name]['hostname'];

            $token = escapeshellarg($_SESSION[$wizard_name]['token']);
            $port = $_SESSION[$wizard_name]['port'];

            $serviceargs = $_SESSION[$wizard_name]['serviceargs'];

            // Escape values for check_command line
            if (function_exists('nagiosccm_replace_command_line')) {
                $token = nagiosccm_replace_command_line($token);
            } else {
                $token = str_replace('!', '\!', $token);
            }

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_windowsserver_host",
                    "host_name" => $hostname,
                    'icon_image' => 'hyperv.png',
                    "address" => $address,
                    "_xiwizard" => $wizard_name,
                    "_ncpa_token" => $token,
                    "_ncpa_port" => $port
                );
            } else {
                /* Just add free variables */
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "host_name" => $hostname,
                    "_ncpa_token" => $token,
                    "_ncpa_port" => $port
                );
            }

            foreach ($serviceargs as $section) {

                foreach ($section as $new_check_arguments) {

                    if (!isset($new_check_arguments['on']) || !$new_check_arguments['on']) {
                        continue;
                    }

                    $warning = escapeshellarg($new_check_arguments['warning']);
                    if (empty($new_check_arguments['warning'])) {
                        $warning = '0:';
                    }

                    $critical = escapeshellarg($new_check_arguments['critical']);
                    if (empty($new_check_arguments['critical'])) {
                        $critical = '0:';
                    }

                    $service_description = "{$new_check_arguments['object']}({$new_check_arguments['instance']})\\{$new_check_arguments['counter']}";

                    $endpoint = "windowscounters/";
                    $endpoint .= $new_check_arguments['object'];
                    if ($new_check_arguments['instance']) {
                        $endpoint .= "({$new_check_arguments['instance']})";
                    }
                    $endpoint .= "/{$new_check_arguments['counter']}";
                    $endpoint = escapeshellarg($endpoint);

                    $queryargs = array();
                    if (isset($new_check_arguments['sleepy'])) {
                        $queryargs[] = 'sleep=1';
                    }

                    if (isset($new_check_arguments['factor'])) {
                        $queryargs[] = 'factor=' . intval($new_check_arguments['factor']);
                    }

                    if (!empty($queryargs)) {
                        $queryargs = " -q " . escapeshellarg(implode(',', $queryargs));
                        $endpoint .= $queryargs;
                    }

                    $full_check_command = "check_xi_hyperv!$endpoint!$warning!$critical";

                    $objs[] = array(
                        'type'                  => OBJECTTYPE_SERVICE,
                        'host_name'             => $hostname,
                        'service_description'   => $service_description,
                        'icon_image'            => 'hyperv.png',
                        'check_command'         => $full_check_command,
                        '_xiwizard'             => $wizard_name,
                    );
                }
            }

            /* Return the object definitions to the wizard */
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            /* clear the session variables for this wizard run */
            unset($_SESSION[$wizard_name]);

            /* The next line ends CONFIGWIZARD_MODE_GETOBJECTS */
            break;

        default:
            break;
    };
    return $output;
}

function hyperv_ncpa_installed_check($url, &$cmd) {
    $url = escapeshellarg($url);
    $cmd = "curl " . $url . " -g -f -k --connect-timeout 10";

    $ret = 0;
    exec($cmd, $data, $ret);
    $data = implode("", $data);

    if ($ret) {
        return 1; // cURL-specific error
    }

    $data = json_decode($data, true);

    if (!$data) {
        return 2; // Not JSON data
    }

    if (!array_key_exists('windowscounters', $data)) {
        return 3; // Not the correct json data
    }

    $found_it = 0; // If this isn't changed, then the output is probably correct

    if (!is_array($data['windowscounters']) && !is_object($data['windowscounters'])) {
        return 4;
    }

    foreach($data['windowscounters'] as $datum) {
        if (strpos($datum, "Error") !== false) {
           $found_it = 4; // NCPA couldn't access the counter, probably because it didn't exist (Hyper-V not installed).
            break;
        }
    }

    return $found_it;
}

function hyperv_build_form_element($element_id, $data_array, $section) {
    $instance_display = '<input type="text" class="form-control form-control-sm rounded instance-name" name="serviceargs['.$section.']['.$element_id.'][instance]" id="serviceargs['.$section.']['.$element_id.'][instance]" value="'.$data_array['instance'].'">';

    if ($data_array['instance'] === '<no instances>') {
        $instance_display = '<input type="hidden" name="serviceargs['.$section.']['.$element_id.'][instance] id="serviceargs['.$section.']['.$element_id.'][instance] value="'.$data_array['instance'].'">';
    }

    $sleepy_display = '';

    if (isset($data_array['sleepy'])) {
        $sleepy_display = '<input type="hidden" id="'.$section.'-'.$element_id.'-sleepy" name="serviceargs['.$section.']['.$element_id.'][sleepy] value="true">';
    }

    $factor_form_element = '<input type="text" id="'.$section.'-'.$element_id.'-factor" class="form-control form-control-sm rounded" value="'.$data_array['factor'].'" name="serviceargs['.$section.']['.$element_id.'][factor]">';

        ob_start();
?>

            <div class="row <?= $section ?>">
                <div class="col-sm-10">
                    <fieldset class="row g-2 mb-1 wz-fieldset">
                        <div class="form-check col-sm-auto mt-0 pt-1">
                            <div class="input-group input-group-sm">
                                <input type="checkbox" id="<?= $section.'-'.$element_id.'-onoff' ?>" class="form-check-input mt-2 me-2 rounded enable-windows-perf-counter" name="serviceargs[<?= $section ?>][<?= $element_id ?>][on]" <?= (array_key_exists('on', $data_array) ? is_checked($data_array['on']) : '') ?>>
                                <label for="<?= $section.'-'.$element_id.'-onoff' ?>" class="form-check-label bold mt-1">
                                    <?= $data_array['object'] ?> (
                                </label>
                                <?= $instance_display ?>
                                <label for="<?= $section.'-'.$element_id.'-onoff' ?>" class="form-check-label bold mt-1">
                                    ) \<?= $data_array['counter'] ?> <?= xi6_info_tooltip($data_array['description']) ?>
                                </label>
                            </div>
                            <div class="row mb-1">
                                <div class="col-sm">
                                    <div class="input-group input-group-sm">
                                        <span class="instance-status" data-sa-index="<?= $element_id ?>" data-sa-section="<?= $section ?>">
                                            <?= _("To verify the instance name, finish editing it or check the checkbox.") ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-1">
                                <div class="col-sm-auto">
                                    <div class="input-group input-group-sm">
                                        <span class="mt-1 me-2"><?= _('Multiply result by 10^') ?></span>
                                        <?= $factor_form_element ?>
                                    </div>
                                </div>
                                <div class="col-sm-3 mt-0">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text">
                                            <i <?= xi6_title_tooltip(_('Warning Threshold')) ?> class="material-symbols-outlined md-warning md-18 md-400">warning</i>
                                        </span>
                                        <input type="text" id="serviceargs[<?= $section ?>][<?= $element_id ?>][warning]" name="serviceargs[<?= $section ?>][<?= $element_id ?>][warning]" value="<?= encode_form_val($data_array['warning']) ?>" class="form-control form-control-sm monitor">
                                        <span class="input-group-text rounded-end">%</span>
                                        <i id="serviceargs_<?= $section ?>_<?= $element_id ?>_warning_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                    </div>
                                </div>
                                <div class="col-sm-3 mt-0">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text">
                                            <i <?= xi6_title_tooltip(_('Critical Threshold')) ?> class="material-symbols-outlined md-critical md-18 md-400">error</i>
                                        </span>
                                        <input type="text" id="serviceargs[disk_critical][<?= $element_id ?>][critical]" name="serviceargs[disk_critical][<?= $element_id ?>][critical]" value="<?= encode_form_val($data_array['critical']) ?>" class="form-control form-control-sm monitor">
                                        <span class="input-group-text rounded-end">%</span>
                                        <i id="serviceargs_<?= $section ?>_<?= $element_id ?>_critical_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-1">
                                <div>
                                    <a class="hyperv-new-counter">+ <?= _("Monitor another instance with this counter") ?></a>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="<?= $section.'-'.$element_id ?>-object" value="<?= $data_array['object'] ?>" name="serviceargs[<?= $section ?>][<?= $element_id ?>][object]">
                        <input type="hidden" id="<?= $section.'-'.$element_id ?>-counter" value="<?= $data_array['counter'] ?>" name="serviceargs[<?= $section ?>][<?= $element_id ?>][counter]">
                        <input type="hidden" id="<?= $section.'-'.$element_id ?>-description" value="<?= $data_array['description'] ?>" name="serviceargs[<?= $section ?>][<?= $element_id ?>][description]">
                        <?= $sleepy_display ?>
                    </fieldset>
                </div>
            </div>
<?php

    $ret = ob_get_clean();

    return $ret;
}
?>
