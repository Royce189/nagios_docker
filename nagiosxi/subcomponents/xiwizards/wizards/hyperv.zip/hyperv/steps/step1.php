    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>" />
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

    <div class="container-fluid m-0 g-0">
<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <div class="col-sm-6 border-block mb-4">
                <h2><?= _('Setup NCPA') ?></h2>
                <p><i><?= _('The agent should be installed before running this wizard') ?></i></p>
                <ul class="list-group list-group-numbered">
                    <li class="list-group-item"><a href="<?= $NCPA_download_url ?>" target="_blank"><?= _('Download the latest version of NCPA') ?></a> <?= _('for the system you would like to monitor.') ?></li>
                    <li class="list-group-item"><?= _('Follow the') ?> <a href="https://www.nagios.org/ncpa/getting-started.php" target="_blank"><?= _('installation instructions.') ?></a> (<a href="https://assets.nagios.com/downloads/ncpa/docs/Installing-NCPA.pdf" target="_blank"><?= _('PDF version') ?></a>) <?= _('and configure the token for the agent') ?></li>
                </ul>
            </div>

            <h2 class="mb-2"><?= _('NCPA Connection') ?></h2>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="ip_address" class="form-label form-item-required"><?= _('IP Address/FQDN') ?> <?= xi6_info_tooltip(_('The IP address or FQDNS name used to connect to NCPA.')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="ip_address" id="ip_address" value="<?= $address ?>" class="form-control monitor rounded" placeholder="<?= _("Enter IP Address/FQDN") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the IP Address/FQDN
                        </div>
                        <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="port" class="form-label form-item-required"><?= _('NCPA Port') ?> <?= xi6_info_tooltip(_('Port used to connect to NCPA. Defaults to port 5693.')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="port" id="port" value="<?= $port ?>" class="form-control monitor rounded" placeholder="<?= _("Enter NCPA Port") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the NCPA Port
                        </div>
                        <i id="port_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label for="token" class="form-label form-item-required"><?= _('NCPA Token') ?> <?= xi6_info_tooltip(_('Authentication token used to connect to NCPA')) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="token" id="token" value="<?= $token ?>" class="form-control monitor rounded" placeholder="<?= _("Enter NCPA Token") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the NCPA Token
                        </div>
                        <i id="token_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
