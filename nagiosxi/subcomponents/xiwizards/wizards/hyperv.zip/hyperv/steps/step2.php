    <!--                                   -->
    <!-- The initial data set from Step 1. -->
    <!--                                   -->
    <input type="hidden" id="hostname" name="hostname" value="<?= encode_form_val($hostname) ?>">
    <input type="hidden" id="operation" name="operation" value="<?= encode_form_val($operation) ?>">
    <input type="hidden" id="selectedhostconfig" name="selectedhostconfig" value="<?= encode_form_val($selectedhostconfig) ?>">
    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

<?php
    #include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';
?>
    <div class="container m-0 g-0">
        <div class="hide" id="instance-ok">
            <i class="material-symbols-outlined md-20 md-400 md-ok md-middle">check_circle</i> <?= _("Instance verified! Current value is ") ?>
        </div>
        <div class="hide" id="instance-pending">
            <i class="material-symbols-outlined md-20 md-400 md-pending md-middle">help</i> <?= _("Verifying instance...") ?>
        </div>
        <div class="hide" id="instance-critical">
            <i class="material-symbols-outlined md-20 md-400 md-critical md-middle">error</i> <?= _("Invalid endpoint. Either the instance name is incorrect or this Windows performance endpoint is not installed.") ?>
        </div>
        <div class="hide" id="token"><?= $token ?></div>
        <div class="hide" id="port"><?= $port ?></div>
        <div class="hide" id="sample-row"></div>

        <h2 class="mb-2"><?= _('Remote Host Details') ?></h2>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="ip_address" class="form-label"><?= _('IP Address') ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter IP Address") ?>" readonly="on">
                    <div class="invalid-feedback">
                        <?= _("Please enter the IP Address") ?>
                    </div>
                    <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <div class="row mb-2">
            <div class="col-sm-6">
                <label for="hostname" class="form-label"><?= _('Host Name') ?> </label>
                <div class="input-group position-relative">
                    <input type="text" name="hostname" id="hostname" value="<?= encode_form_val($hostname)  ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter Host Name") ?>" >
                    <div class="invalid-feedback">
                        <?= _("Please enter the Host Name") ?>
                    </div>
                    <i id="hostname_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                </div>
            </div>
        </div>

        <!--                         -->
        <!-- The metrics to monitor. -->
        <!--                         -->
<?php
    $cpu_endpoints = array(
        array(
            'object' => "Hyper-V Hypervisor Logical Processor",
            'instance' => "_Total",
            'counter' => '% Total Run Time',
            'warning' => '85',
            'critical' => '90',
            'description' => _("The total physical CPU usage for the host server."),
            'on' => true,
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Hypervisor Root Virtual Processor",
            'instance' => "_Total",
            'counter' => "% Guest Run Time",
            'warning' => '',
            'critical' => '',
            'description' => _("The total CPU usage spent on guest VMs."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Hypervisor Logical Processor",
            'instance' => "_Total",
            'counter' => "Context Switches/sec",
            'warning' => '',
            'critical' => '',
            'description' => _("A general health indicator for the server. Should usually be <200,000 per processor."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Hypervisor Virtual Processor",
            'instance' => "*", 
            'counter' => "% Guest Run Time",
            'warning' => '',
            'critical' => '',
            'description' => _("CPU usage for each virtual processor on each VM."),
            'sleepy' => true,
            'factor' => '0')
    );

    $form_element_counter = 0;
    $section = 'cpu';
?>
        <h2 class="mt-4 mb-2"><?= _("CPU Counters") ?></h2>

        <div id="<?= $section ?>">
<?php
    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $cpu_endpoints = $serviceargs[$section];
    }

    foreach ($cpu_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

<?php
    $memory_endpoints = array(
        array(
            'object' => "Hyper-V Dynamic Memory Balancer", 
            'instance' => '*', 
            'counter' => 'Available Memory', 
            'warning' => '4000:', 
            'critical' => '2000:',
            'description' => _("The amount of memory available for VMs (in MB)."), 
            'on' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Dynamic Memory VM", 
            'instance' => '*', 
            'counter' => 'Average Pressure', 
            'warning' => '75', 
            'critical' => '85',
            'description' => _("The proportion of memory committed versus allocated for each VM."),
            'factor' => '0'),
        array(
            'object' => "Hyper-V Dynamic Memory VM", 
            'instance' => '*', 
            'counter' => 'Physical Memory', 
            'warning' => '', 
            'critical' => '', 
            'description' => _("The amount of allocated memory for each machine (in MB)."),
            'factor' => '0')/*,
        array(
            'object' => "Hyper-V VM Vid Partition",
            'instance' => '', 
            'counter' => 'Remote Physical Pages', 
            'warning' => '', 
            'critical' => '', 
            'description' => _("This is really hard to monitor with the way things are set up currently. We want to make sure the counter increases by less than 100/hr."))*/
    );

    $form_element_counter = 0;
    $section = 'memory';
?>
        </div>

        <h2 class="mt-4 mb-2"><?= _("Memory Counters") ?></h2>

        <div id="<?= $section ?>">
<?php
    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $memory_endpoints = $serviceargs[$section];
    }

    foreach ($memory_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

<?php
    $networking_endpoints = array(
        array(
            'object' => "Network Interface", 
            'instance' => '*', 
            'counter' => 'Bytes Total/sec', 
            'warning' => '', 
            'critical' => '',
            'description' => _("Shows the network usage for each physical NIC."),
            'on' => true,
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Virtual Network Adapter", 
            'instance' => '*', 
            'counter' => 'Bytes/sec', 
            'warning' => '', 
            'critical' => '',
            'description' => _("Shows the network usage for each VM network adapter."),
            'sleepy' => true,
            'factor' => '0'),
    );

    $form_element_counter = 0;
    $section = 'networking';
?>
        </div>

        <h2 class="mt-4 mb-2"><?= _("Networking Counters") ?></h2>

        <div id="<?= $section ?>">
<?php
    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $networking_endpoints = $serviceargs[$section];
    }

    foreach ($networking_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

<?php
    // TODO: 
    $local_storage_endpoints = array(
        array(
            'object' => "LogicalDisk", 
            'instance' => '*', 
            'counter' => 'Avg. Disk sec/Transfer',
            'warning' => '20', 
            'critical' => '25',
            'description' => _("Measures disk latency for the virtual machine data. Multiplying by 10^3 gives latency in milliseconds."),
            'on' => true,
            'sleepy' => true,
            'factor' => '3'),
        array(
            'object' => "LogicalDisk",
            'instance' => '*',
            'counter' => '% Idle Time',
            'warning' => '60:',
            'critical' => '50:',
            'description' => _("Shows the amount of time where the disk is in an idle state. This is a general indicator of VM responsiveness, and performance will be dramatically reduced after the thresholds shown here."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "LogicalDisk",
            'instance' => '*',
            'counter' => 'Free Megabytes',
            'warning' => '',
            'critical' => '',
            'description' => _("The amount of free space on a disk. Low disk space can result in VM outages."),
            'factor' => '0'),
        array(
            'object' => "LogicalDisk",
            'instance' => '*',
            'counter' => 'Disk Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Shows disk throughput for the host instance."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "LogicalDisk",
            'instance' => '*',
            'counter' => 'Disk Transfers/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS counter for local disks. Typically used for capacity planning rather than threshold checking."),
            'sleepy' => true,
            'factor' => '0')
    );

    $form_element_counter = 0;
    $section = 'local-storage';
?>
        </div>

        <h2 class="mt-4 mb-2"><?= _("Local Storage Counters") ?></h2>

        <div id="<?= $section ?>">
<?php
    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $local_storage_endpoints = $serviceargs[$section];
    }

    foreach ($local_storage_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

<?php
    $virtual_storage_endpoints = array(
        array(
            'object' => "Hyper-V Virtual Storage Device",
            'instance' => '*',
            'counter' => 'Read Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Shows virtual disk output for a particular VM."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Virtual Storage Device",
            'instance' => '*',
            'counter' => 'Write Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Shows virtual disk input for a particular VM."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Virtual Storage Device",
            'instance' => '*',
            'counter' => 'Read Operations/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS output counter for a particular VM."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Hyper-V Virtual Storage Device",
            'instance' => '*',
            'counter' => 'Write Operations/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS input counter for a particular VM."),
            'sleepy' => true,
            'factor' => '0')
    );

    $form_element_counter = 0;
    $section = 'virtual-storage';
?>
        </div>

        <h2 class="mt-4 mb-2"><?= _("Virtual Storage Counters") ?></h2>

        <div id="<?= $section ?>">
<?php

    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $virtual_storage_endpoints = $serviceargs[$section];
    }

    foreach ($virtual_storage_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

<?php
    $ha_storage_endpoints = array(
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'Read Latency',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk Latency for reading from CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'Write Latency',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk Latency for writing to CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'IO Read Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk Throughput for reading from CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'IO Write Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk Throughput for writing to CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'IO Reads/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS counter for reading from CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "Cluster CSV File System",
            'instance' => '*',
            'counter' => 'IO Writes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS counter for writing to CSV Disks."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "SMB Client Shares",
            'instance' => '*',
            'counter' => 'Avg. sec/Data Request',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk Latency for SMB shares. Multiplying by 10^3 gives latency in milliseconds."),
            'sleepy' => true,
            'factor' => '3'),
        array(
            'object' => "SMB Client Shares",
            'instance' => '*',
            'counter' => 'Data Bytes/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("Disk throughput for SMB Shares."),
            'sleepy' => true,
            'factor' => '0'),
        array(
            'object' => "SMB Client Shares",
            'instance' => '*',
            'counter' => 'Data Requests/sec',
            'warning' => '',
            'critical' => '',
            'description' => _("The IOPS counter for SMB Shares."),
            'sleepy' => true,
            'factor' => '0')
    );

    $form_element_counter = 0;
    $section = 'ha-storage';
?>
        </div>

        <h2 class="mt-4 mb-2"><?= _("High-Availability Storage Counters") ?></h2>

        <div id="<?= $section ?>">
<?php
    if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
        $ha_storage_endpoints = $serviceargs[$section];
    }

    foreach ($ha_storage_endpoints as $endpoint) {
        $element_id = strval($form_element_counter++);
        echo(hyperv_build_form_element($element_id, $endpoint, $section));
    }
?>

    </div> <!-- container -->

    <script src="../includes/configwizards/hyperv/hyperv.inc.js"></script>

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
