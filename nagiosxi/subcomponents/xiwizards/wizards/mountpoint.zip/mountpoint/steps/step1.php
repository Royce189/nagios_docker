<input type="hidden" name="service_description" value="<?= encode_form_val($service_description) ?>" />
<input type="hidden" name="mtab" value="<?= encode_form_val($mtab) ?>" />
<input type="hidden" name="fstab" value="<?= encode_form_val($fstab) ?>" />
<input type="hidden" name="FSF" value="<?= encode_form_val($FSF) ?>" />
<input type="hidden" name="MF" value="<?= encode_form_val($MF) ?>" />
<input type="hidden" name="OF" value="<?= encode_form_val($OF) ?>" />
<input type="hidden" name="rtime" value="<?= encode_form_val($rtime) ?>" />
<input type="hidden" name="softlink" value="<?= encode_form_val($softlink) ?>" />
<input type="hidden" name="ignorefs" value="<?= encode_form_val($ignorefs) ?>" />
<input type="hidden" name="auto" value="<?= encode_form_val($auto) ?>" />
<input type="hidden" name="write" value="<?= encode_form_val($write) ?>" />

<h5 class="ul"><?= _('Mountpoint Host Description') ?></h5>
<p style="max-width: 500px;">
<?=  _('This wizard will check if the specified mountpoints exist on your XI instance and if they are correctly implemented. These are the supported mountpoint types: nfs, nfs4, davfs, cifs, fuse, simfs, glusterfs, ocfs2, lustre, xfs') ?>.
</p>