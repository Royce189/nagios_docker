#!/bin/bash

WIZARD_DIR=$(dirname $(readlink -f $0))
cd "$WIZARD_DIR"
# We are currently in  get_base_dir().'/includes/configwizards/'.$name

BASE_DIR="$WIZARD_DIR/../../../.."
CFG_DIR="$BASE_DIR/etc/configwizards/oracle"
ORACLE_FILE="$CFG_DIR/oracle"

if [ ! -d "$CFG_DIR" ]; then
	mkdir -p "$CFG_DIR"
fi

if [ ! -f "$ORACLE_FILE" ]; then
	touch "$ORACLE_FILE"
fi

if [ ! -s "$CFG_DIR/oracle" ]; then
	# Default content for the oracle file
	cat << EOF > "$CFG_DIR/oracle"
export LD_LIBRARY_PATH=/usr/lib/oracle/11.2/client/lib
export ORACLE_HOME=/usr/lib/oracle/11.2/client
EOF
fi
