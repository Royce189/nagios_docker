<?php
//
// VSphere Config Wizard
// Copyright (c) 2008-2021 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

vsphere_configwizard_init();

// Originally this was just VSPHERE_SERVICENAMES. It was split up into two nested arrays as the subcommands for the commands can differ based on if it is viewing guests or hosts on VMWare.
define('VSPHERE_SERVICENAMES_HOST',
    json_encode(array(
            array('CPU', TRUE, 'CPU Usage', '%, MHz - Example: 30,200', 'Usage', 'UsageMHZ'),
            array('MEM', TRUE, 'Memory', '%, MB, Overhead, Swapped, Memctl, Consumed - Example: 30,200,10,10,5,5000', 'Usage', 'UsageMB', 'Swap', 'OverHead', 'MemCtl'),
            array('NET', TRUE, 'Networking', 'Recive, Send, nics connected - Example: 5,5,3', 'Usage', 'Recieve', 'Send', 'NIC'),
            array('IO', TRUE, 'Input / Output', 'Usage, Read, Write - Example: 1,0.5,0.1', 'Usage', 'Read', 'Write'),
            array('VMFS', FALSE, 'Datastore usage', 'Space free for each datastore - Example for 2 datastores: 400000,250000', 'Name'),
            array('RUNTIME', TRUE, 'VM Status', 'State, Connection , Uptime - Thresholds not currently implemented for this metric', 'Con', 'Health', 'StorageHealth', 'Temperature', 'Sensor', 'Maintenance', 'ListVm', 'Status', 'Issues'),
            array('SERVICE', FALSE, 'Services', 'States of the services - Thresholds not currently implemented for this metric', 'Names'),
            // array('RUNTIME', TRUE, 'VM Status', 'State, Connection , Uptime - Example: Down,Disconnected,50d', 'Con', 'Health', 'StorageHealth', 'Temperature', 'Sensor', 'Maintenance', 'ListVm', 'Status', 'Issues'),
            // array('SERVICE', FALSE, 'Services', 'States of the services - Example: Down,Down,Down,Down,Down,Up,Up,Down,...etc', 'Names'),
        )
    )
);

define('VSPHERE_SERVICENAMES_GUESTS',
    json_encode(array(
            array('CPU', TRUE, 'CPU Usage', '%, MHz, wait, ready - Example: 30,350,50000,50', 'Usage', 'UsageMHZ', 'Wait', 'Ready'),
            array('MEM', TRUE, 'Memory', '%, MB, Overhead, Swapped, Swap in, Swap out, Memctl, Consumed - Example: 40,300,50,5,5,5,10,5000', 'Usage', 'UsageMB', 'Swap', 'OverHead', 'Active', 'MemCtl'),
            array('NET', TRUE, 'Networking', 'Recieve, Send - Example: 5,5', 'Usage', 'Recieve', 'Send'),
            array('IO', TRUE, 'Input / Output', 'Usage, Read, Write - Example: 5,5,5', 'Usage', 'Read', 'Write'),
            array('VMFS', FALSE, 'Datastore usage', 'Space free for each datastore - Example for 2 datastores: 400000,250000', 'Name'),
            array('RUNTIME', TRUE, 'VM Status', 'State, Status, Connection, Console, Max cpu, Max memory, Tools - Thresholds not currently implemented for this metric', 'Con', 'Cpu', 'Mem', 'State', 'Status', 'ConsoleConnetions', 'Guest', 'Tools', 'Issues'),
            // array('RUNTIME', TRUE, 'VM Status', 'State, Status, Connection, Console, Max cpu, Max memory, Tools, Config issues - Example: DOWN,red,Disconnected,1,3300:,3500:,down,1', 'Con', 'Cpu', 'Mem', 'State', 'Status', 'ConsoleConnetions', 'Guest', 'Tools', 'Issues'),
        )
    )
);

define('VSPHERE_BASICDATA',
    json_encode(array(
            array(
                array("wng", "warning", "Warning"),
                array("crt", "critical", "Critical"),
            ),
            array(
                array("low", "low", "%s Below:"),
                array("hi", "high", "Above:"),
            )
        )
    )
);

define('VSPHERE_HOSTINPUTF', '');

function vsphere_configwizard_init()
{
    $name = 'vsphere';
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.0.3",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _('Monitor a VMware host or guest VM.'),
        CONFIGWIZARD_DISPLAYTITLE => _('vSphere'),
        CONFIGWIZARD_FUNCTION => 'vsphere_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'vsphere.png',
        CONFIGWIZARD_REQUIRES_VERSION => 60003
    );
    register_configwizard($name, $args);
}

/**
 * Checks to verify that VMware SDK is installed
 * 
 */
function vsphere_configwizard_check_prereqs()
{
    $checkCmd = "python3 --version";
    $checkOutput = shell_exec($checkCmd);
    if (strpos($checkOutput, 'Python 3') === false){
        return false;
    }

    $checkCmd = "python3 -m pip show pyvmomi";
    $checkOutput = shell_exec($checkCmd);

    if (strpos($checkOutput, 'Name: pyvmomi') === false){
        //// Trying to install here is really slow and delays the wizard loading by a long time. TODO: better solution?
        // $installCmd = "python3 -m pip install --upgrade pyvmomi";
        // $installOutput = shell_exec($installCmd);
        // if (strpos($installOutput, 'Successfully installed') === false) {
        //     return false;
        // }
        return false;
    }
    return true;
}

/**
 * @param null $inargs
 *
 * @return array
 */
function vsphere_configwizard_parseinargs($inargs = null)
{
    // Get variables that were passed to us
    $address = grab_array_var($inargs, 'ip_address', '');
    $hostname = grab_array_var($inargs, 'hostname', '');
    $ha = '';
    if ($hostname == '') {
        $ha = $address == '' ? '' : @gethostbyaddr($address);
        if ($ha == '')
            $ha = $address;
    }
    $hostname = grab_array_var($inargs, 'hostname', $ha);
    $type = grab_array_var($inargs, 'type', 'host');
    $username = grab_array_var($inargs, 'username', '');
    $password = grab_array_var($inargs, 'password', '');

    $services_serial = grab_array_var($inargs, 'services_serial', '');
    $serviceargs_serial = grab_array_var($inargs, 'serviceargs_serial', '');
    $guests_serial = grab_array_var($inargs, 'guests_serial', '');

    $services = json_decode(base64_decode($services_serial), true);
    $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
    $guests = json_decode(base64_decode($guests_serial), true);
    if (!is_array($services))
        $services = array();
    if (!is_array($serviceargs))
        $serviceargs = array();
    if (!is_array($guests))
        $guests = array();
    $srvlock = 0;
    $guestlock = 0;

    foreach (array_keys($inargs) as $argu) {
        if ( preg_match('/^activate_(.*)$/', $argu, $matches)) {
            if (!$guestlock) {
                $guests = array();
                $guestlock = -1;
            }
            $argt = base64_decode($matches[1]);
            $guests[$argt] = grab_array_var($inargs, "alias_".$matches[1], $argt);
        }
        if (preg_match('/^service_(.*)$/', $argu, $matches)) {
            if (!$srvlock) {
                $services = array();
                $srvlock = -1;
            }
            $services[$matches[1]] = TRUE;
        }
        if (preg_match('/^serviceargs_([^-]*)-(.*)$/', $argu, $matches)) {
            $argt = $matches[1] . '_' . $matches[2];
            if (array_search($argt, $serviceargs) === FALSE)
                $serviceargs[$argt] = grab_array_var($inargs, $argu, '');
        }
    }
    if (empty($serviceargs)) {
        $serviceargs = grab_array_var($inargs, 'serviceargs', array());
    }

    unset ($argu);

    return array($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests);
}

/**
 * @param $output
 * @param $s
 * @param $services
 * @param $serviceargs
 * @param $mode
 */
function vsphere_configwizard_pushcheckboxandargs(&$output, $s, $services, $serviceargs, $mode, $disabled = false)
{
    $sl = strtolower($s[0]);

    $rowstyles = 'display:inline-flex;justify-content:space-between;align-items:center;';
    $tdstyles = 'vertical-align:center;';
    $output .= '<tr>
                    <td style="' . $tdstyles . '">
                        <input type="checkbox" 
                            class="service_checkbox" 
                            id="ckhbx_' . encode_form_val($sl) . '" 
                            name="service_' . encode_form_val($sl) . '" 
                            checked="yes"' . (array_key_exists($sl, $services) ? ' 
                            checked="yes"' : '') . ' 
                            style="bottom: 1px;">
                        </input>
                    </td>
                    <td style="' . $tdstyles . '">
                        <label for="serviceargs['. $sl .'_warning]">'. encode_form_val($s[2]) .'</label>
                        <i class="fa fa-question-circle pop" title="'. $s[3] .'" style="margin-left: 5px;"></i>
                    </td>
                    <td style="' . $tdstyles . '">
                        <span class="input-group-text" style="margin: 0 5px 0 0">
                            <i title="'._('Warning Threshold') .'" class="material-symbols-outlined md-warning md-18 md-400 md-middle">warning</i>
                        </span>
                        <input type="text" 
                            id="serviceargs['. $sl .'_warning]" 
                            name="serviceargs['. $sl .'_warning]" 
                            value="'. encode_form_val($serviceargs[$sl . '_warning']) .'" 
                            class="form-control" '. ($disabled ? 'disabled' : '') .'>
                        <i id="serviceargs_'. $sl .'_warning_Alert-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </td>
                    <td style="' . $tdstyles . '">
                        <span class="input-group-text" style="margin: 0 5px 0 0">
                            <i title="'._('Critical Threshold') .'" class="material-symbols-outlined md-critical md-18 md-400 md-middle">error</i>
                        </span>
                        <input type="text" 
                            id="serviceargs['. $sl .'_critical]" 
                            name="serviceargs['. $sl .'_critical]" 
                            value="'. encode_form_val($serviceargs[$sl . '_critical']) .'" 
                            class="form-control" '. ($disabled ? 'disabled' : '') .'>
                        <i id="serviceargs_'. $sl .'_critical_Alert-sm" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </td>
                </tr>';



    // TODO: If we add subcommands to the wizard this code will need to be added above to add a metrics select box. Currently it doesn't make sense to leave metrics in without subcommands as the different metrics should have different metric values.
    //     <div class="col-sm-3 mt-0">
    //     <label>'. _('Metrics').'</label>
    //     <select name="serviceargs['.$sl.'_metrics]" id="serviceargs['. $sl . '_metrics]" class="form-control">
    //         <option value="percentage">%</option>
    //         <option value="B">B</option>
    //         <option value="KB">KB</option>
    //         <option value="Kib">Kib</option>
    //         <option value="MB">MB</option>
    //         <option value="Mib">Mib</option>
    //         <option value="GB">GB</option>
    //         <option value="Gib">Gib</option>
    //         <option value="TB">TB</option>
    //         <option value="Tib">Tib</option>
    //     </select>
    // </div>
}

/**
 * @param $serviceargs
 * @param $svcl
 *
 * @return string
 */
function vsphere_configwizard_getrangeargs($serviceargs, $svcl)
{
    $ret = [];

    $svclargs = array();
    foreach ($serviceargs as $key => $value) {
        if (strpos($key, $svcl) === 0) {
            $svclargs[$key] = $value;
        }
    }
    $warning = $svclargs[$svcl . '_warning'];
    $critical = $svclargs[$svcl . '_critical'];
    if (!($warning == ''))
        $ret[] = '-w' . $warning;
    if (!($critical == ''))
        $ret[] = '-c' . $critical;

    // TODO: if subcommands are added we will want to add metrics back in. We will need to change how critical/warning thresholds are done as they will no longer be given in a csv with subcommands. May look like the commented code below.
    // $metrics = $svclargs[$svcl . '_metrics'];
    // if (!($warning == ''))
    //     $ret .= ' -w ' . $warning;
    // if (!($critical == ''))
    //     $ret .= ' -c ' . $critical;
    // used for subcommand metrics
    // if (!($metrics == 'percentage'))
    //     $ret .= ' -U ' . $metrics;
    return $ret;
}


/**
 * @param $objs
 * @param $type
 * @param $hostname
 * @param $address
 * @return array
 */
function vsphere_configwizard_makehost(&$objs, $type, $hostname, $address)
{
    return array(
        'type' => OBJECTTYPE_HOST,
        'use' => 'xiwizard_generic_host',
        'host_name' => $hostname,
        'address' => $address,
        'icon_image' => 'vsphere.png',
        'statusmap_image' => 'vsphere.png',
        '_xiwizard' => 'vsphere',
    );
}

/**
 * @param $objs
 * @param $hostname
 * @param $address
 * @param $type
 * @param $services
 * @param $serviceargs
 * @param $guests
 */
function vsphere_configwizard_makeservices(&$objs, $hostname, $address, $type, $services, $serviceargs, $guests)
{
    // TODO: If we are doing subcommands we will need to change how we loop through the services. The current version only checks
    // the main command itself and doesnt go into the sub commands, i.e. -l cpu vrs -l cpu -s Usage. -s being the subcommand for cpu
    $fil = get_root_dir() . '/etc/components/vsphere/' . preg_replace("/[ '.\:_-]/", '_', $hostname) . '_auth.txt';
    if (!host_exists($hostname))
        $objs[] = vsphere_configwizard_makehost($objs, $type, $hostname, $address);
    switch ($type) {
        case 'guest':
            foreach ($guests as $guestaddress => $guestname) {
                $guestname = str_replace(',', '', $guestname);

                // see which services we should monitor
                foreach (json_decode(VSPHERE_SERVICENAMES_GUESTS, true) as $s) {
                    $sl = strtolower($s[0]);
                    if (array_key_exists($sl, $services)) {
                        $warn = vsphere_configwizard_getrangeargs($serviceargs, $sl);
                        $objs[] = array(
                            'type' => OBJECTTYPE_SERVICE,
                            'host_name' => $hostname,
                            'service_description' => "{$guestname} {$s[2]}",
                            'use' => 'xiwizard_generic_service',
                            'check_command' => "check_vsphere_guest_xi!$fil!$guestaddress!" . $s[0] . "!$warn[0]" . "!$warn[1]",
                            '_xiwizard' => 'vsphere',
                        );
                    }
                }
            }
            break;

        case 'host':

            // see which services we should monitor
            foreach (json_decode(VSPHERE_SERVICENAMES_HOST, true) as $s) {
                $sl = strtolower($s[0]);
                if (array_key_exists($sl, $services)) {
                    $warn = vsphere_configwizard_getrangeargs($serviceargs, $sl);
                    $objs[] = array(
                        'type' => OBJECTTYPE_SERVICE,
                        'host_name' => $hostname,
                        'service_description' => $s[2] . " for vSphere Host",
                        'use' => 'xiwizard_generic_service',
                        'check_command' => 'check_vsphere_host_xi!' . $fil . '!' . $s[0] . "!$warn[0]" . "!$warn[1]",
                        '_xiwizard' => 'vsphere',
                    );
                }
            }

            // Commands below are for datastores to be checked.
            foreach ($guests as $guest) {
                $objs[] = array(
                    'type' => OBJECTTYPE_SERVICE,
                    'host_name' => $hostname,
                    'service_description' => "Datastore $guest for vSphere Host",
                    'use' => 'xiwizard_generic_service',
                    'check_command' => 'check_vsphere_datastore_xi!' . $fil . '!' . $guest . '!',
                    '_xiwizard' => 'vsphere',
                );
            }
            break;

        default:
            break;
    }
}

/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function vsphere_configwizard_func($mode = '', $inargs = null, &$outargs = null, &$result = null)
{
    // Initialize return code and output
    $result = 0;
    $output = '';

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $output = '';

            if (vsphere_configwizard_check_prereqs() == false) {
                $output .= '<div class="message" style="margin-top: 20px;">
                                <ul class="actionMessage">
                                    <li>
                                    '._('It appears as though you have not installed the necessary Python packages. Once you have Python3 installed, you will need to install the pyvmomi package.
                                    You can install the pyvmomi package by running the following commands:').'</li>
                                    <pre>
'                                       . 'python3 -m pip install --upgrade pip
'                                       . 'python3 -m pip install --upgrade setuptools wheel
'                                       . 'python3 -m pip install --upgrade pyvmomi</pre>
                                    <li>'._('Please refer to the following documentation for more information:').' <strong><a href="http://nagios.force.com/support/s/article/Monitoring-vSphere-95b1aa22" target="_blank">'._('Monitoring vSphere with Nagios XI').'</a></strong> '._('documentation').'</a></strong> </li>
                                </ul>
                            </div>';
            
            } else {
                list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

                $output .= '
<input type="hidden" name="services_serial" value="' . encode_form_val(base64_encode(json_encode($services))) . '">
<input type="hidden" name="serviceargs_serial" value="' . encode_form_val(base64_encode(json_encode($serviceargs))) . '">
<input type="hidden" name="guests_serial" value="' . encode_form_val(base64_encode(json_encode($guests))) . '">

<h5 class="ul">' . _('VMware Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>' . _('Address') . ':</label>
        </td>
        <td>
            <input type="text" size="30" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control" autocomplete="ip_address">
            <div class="subtext">' . _('The IP address or FQDNS name of the VCenter (server) or ESXi host you would like to monitor.') . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Username') . ':</label>
        </td>
        <td>
            <input type="text" size="30" name="username" id="username" value="' . encode_form_val($username) . '" class="form-control">
            <div class="subtext">' . _('The username used to authenticate on the VMware server.') . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Password') . ':</label>
        </td>
        <td>
            <input type="password" size="30" name="password" id="password" value="' . encode_form_val($password) . '" class="form-control">
            <div class="subtext">' . _('The password used to authenticate on the VMware server.') . '</div>
        </td>
    </tr>
    <tr>
        <td>
            <label>' . _('Monitoring Mode') . ':</label>
        </td>
        <td>    
            ' . _('Would you like to monitor the VMware host (server) or a guest VM?') . '
            <div class="pad-t5">
                <div class="radio">
                    <label><input type="radio" name="type" value="host" ' . ($type === "host" ? ' checked="yes"' : '') . '>' . _('Monitor the VMware host') . '</label>
                </div>
                <div class="radio">
                    <label><input type="radio" name="type" value="guest" ' . ($type === "guest" ? ' checked="yes"' : '') . '>' . _('Monitor a guest VM on the VMWare host') . '</label>
                </div>
            </div>
        </td>
    </tr>
</table>';

            }
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

            // check for form errors
            $errors = 0;
            $errmsg = array();
            
            if (vsphere_configwizard_check_prereqs() == false) {
                $errmsg[$errors++] = _('Required software components are missing.');
            } else {
                if (have_value($address) == false) {
                    $errmsg[$errors++] = _('No address specified.');
                }
                if (have_value($username) == false) {
                    $errmsg[$errors++] = _('Username not specified.');
                }
                if (have_value($password) == false) {
                    $errmsg[$errors++] = _('Password not specified.');
                }
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

            $output = '
<input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
<input type="hidden" name="type" value="' . encode_form_val($type) . '">
<input type="hidden" name="username" value="' . encode_form_val($username) . '">
<input type="hidden" name="password" value="' . encode_form_val($password) . '">

<h5 class="ul">' . _('VMware Details') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>' . _('VMware Mode') . ':</label>
        </td>
        <td>
            ' . ucfirst(encode_form_val($type)) . '
        </td>
    </tr>
    <tr>
        <td>
            <label>' . _('Address') . ':</label>
        </td>
        <td>
            <input type="text" size="20" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Host Name') . ':</label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control">
            <div class="subtext">' . _('The name you\'d like to have associated with this host.') . '</div>
        </td>
    </tr>
</table>';

            switch ($type) {
                case 'guest':

                    $output .= '    <script type="text/javascript">
                                $(function() 
                                {
                                    $("#vsphere_settings").tabs();
                                });
                                $(document).ready(function() {
                                    $(\'#checkAll2\').click(function(event) {  //on click
                                        if(this.checked) { // check select status
                                            $(\'#vsphere_settings-2 input:checkbox\').each(function() { //loop through each checkbox
                                                this.checked = true;  //select all checkboxes with class "checkbox1"              
                                            });
                                        }else{
                                            $(\'#vsphere_settings-2 input:checkbox\').each(function() { //loop through each checkbox
                                                this.checked = false; //deselect all checkboxes with class "checkbox1"                      
                                            });        
                                        }
                                    });
                                   
                                });
                                </script>

                                <div id="vsphere_settings" style="margin-top: 20px;">
                                    <ul>
                                        <li><a href="#vsphere_settings-1">' . _('Monitored Metrics') . '</a></li>
                                        <li><a href="#vsphere_settings-2">' . _('Guest Selection') . '</a></li>
                                    </ul>
                                    <div id="vsphere_settings-1">
                                        <h5 class="ul" style="padding-bottom:0;">' . _('VMware Monitored Metrics') . '</h5>
                                        <p>' . _('Select the metrics you\'d like to monitor on each of the guests you select. The fields below take multiple values. See the tool tips for examples. For more information view our ') . '<a href="" target="_blank">'. _('documentation') .'</a>.</p>
                                        <script type="text/javascript">
                                            function toggleCheckboxes(status) {
                                                var checkboxes = document.getElementsByClassName("service_checkbox");
                                                for (var i = 0; i < checkboxes.length; i++) {
                                                    checkboxes[i].checked = status;
                                                }
                                            }
                                        </script>
                                        <style>
                                            #vsphere_metrics table tbody tr td {
                                                padding: 3px 12px;
                                            }
                                            #vsphere_metrics table tbody tr:first-child td {
                                                padding: 6px 12px 3px 12px;
                                            }
                                        </style>
                                        <div id="vsphere_metrics">
                                            <table class="table table-condensed table-no-border table-auto-width" style="margin-bottom:5px;">
                                                <thead>
                                                    <tr>
                                                    <th style="vertical-align:center; padding-left:12px; padding-right:0px;"><input type="checkbox" id="checkAll1" title="'._('Check All').'" onclick="toggleCheckboxes(this.checked)" checked="yes"></th>
                                                    <th>' . _('Metric') . '</th>
                                                    <th style="padding-left:40px">' . _('Warning Threshold') . '</th>
                                                    <th style="padding-left:40px">' . _('Critical Threshold') . '</th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                    foreach (json_decode(VSPHERE_SERVICENAMES_GUESTS, true) as $s) {
                        if (in_array($s[0] , array('RUNTIME', 'SERVICE'))) {
                            vsphere_configwizard_pushcheckboxandargs($output, $s, $services, $serviceargs, $mode, $disabled=true);
                        } else {
                            vsphere_configwizard_pushcheckboxandargs($output, $s, $services, $serviceargs, $mode);
                        }
                    };
                    
                    $output .= '            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <style>
                                div#vsphere_settings-2 table tbody tr td {
                                    padding: 3px 12px;
                                }
                                div#vsphere_settings-2 table tbody tr:first-child td {
                                    padding: 6px 12px 3px 12px;
                                }
                            </style>
                            <div id="vsphere_settings-2">';

                    // Run the get guests perl file to get a list of guest VMs...
                    $cmd = get_root_dir() . '/html/includes/configwizards/vsphere/plugins/check_vsphere_xi.py -H ' . escapeshellarg($address) . ' -u ' . escapeshellarg($username) . ' -p ' . escapeshellarg($password) . ' -G';
                    $proc = proc_open($cmd, array(1 => array('pipe', 'w'), 2 => array('pipe', 'w')), $pipes);
                    if (is_resource($proc)) {
                        $data = stream_get_contents($pipes[1]);
                        fclose($pipes[1]);
                        $stderr = stream_get_contents($pipes[2]);
                        fclose($pipes[2]);
                        proc_close($proc);
                    }

                    $data = explode("\n", $data);

                    if (!empty($stderr)) {
                        $output .= '    <h5 class="ul">' . _('Error') . '</h5>
                                        <p>' . _('It appears there are no guests for this VMware host. The error message is below. This may be because the SDK is not installed, your credentials are wrong, or the host is not a VMware server.') . '</p>
                                        <pre>' . $stderr . '</pre>
                                    </div>
                                </div>';
                        return $output;
                    }

                    $output .= '    <h5 class="ul" style="padding-bottom:0;">' . _('VMware Guest Selection') . '</h5>
                            <p>' . _('Specify which guests you\'d like to monitor on the VMware host (server).') . '</p>
                            <table class="table table-condensed table-no-border table-auto-width" style="margin-bottom:5px;">
                                <thead>
                                    <tr>
                                        <th style="vertical-align:middle;horizontal-align:middle;"> <input type="checkbox" id="checkAll2" title="'._('Check All').'"></th>
                                        <th>' . _('VM Name') . '</th>
                                        <th>' . _('IP Address') . '</th>
                                        <th>' . _('Current Status') . '</th>
                                    </tr>
                                </thead>
                                <tbody>';
                    $rownumber = 2; //Used for determing row color
                    $rowstyles = 'vertical-align:middle;horizontal-align:middle;';
                    foreach ($data as &$element) {
                        ($rownumber++ % 2) ? $tclass = 'odd' : $tclass = 'even';
                        $element = explode("\t", $element);
                        $nam = base64_encode($element[0]);
                        $idnt = $element[0];
                        if(empty($nam))
                            continue;
                        $nametextfield = sprintf('<input type="text" size="35" name="alias_%s" id="alias_%s" value="%s" class="form-control">', encode_form_val($nam), encode_form_val($nam), encode_form_val(array_key_exists($idnt, $guests) ? $guests[$idnt] : $idnt));

                        /* Now we will draw the tables.
                            $element[0] is the VM Name (Text Field) set to $nametextfield for readability.
                            $element[2] is the IP Address and is used to set $ipaddress variable.
                            $element[3] is the VM status and is used to set $powerstatus variable.*/
                        // Setting nice looking powerestatus variable.
                        ($element[3] == 'poweredOff') ? $powerstatus = '<font color="gray">' . _('Powered Off') . '</font>' : $powerstatus = '<font color="Green"><b>' . _('Powered On') . '<b></font>';
                        // Setting nice looking ipaddress variable.
                        ($element[2] == '') ? $ipaddress = '<font color="gray">' . _('None Defined') . '</font>' : $ipaddress = '<b>' . $element[2] . '</b>';
                        if (count($guests) === 0) {
                            //print_r($element);
                            $output .= '    <tr class="' . $tclass . '">
                                            <td style="' . $rowstyles . '">
                                                <input type="checkbox" name="activate_' . encode_form_val($nam) . '"' . ($element[3] === 'poweredOn' ? ' checked="yes"' : '') . '>';
                        } else {
                            $output .= '    <tr>
                                            <td style="' . $rowstyles . '">
                                                <input type="checkbox" name="activate_' . encode_form_val($nam) . '"' . (array_key_exists($idnt, $guests) ? ' checked="yes"' : '') . '>';
                        }

                        $output .= '        </td>
                                        <td style="' . $rowstyles . '">' . $nametextfield . '</td>
                                        <td style="' . $rowstyles . '">' . $ipaddress . '</td>
                                        <td style="' . $rowstyles . '">' . $powerstatus . '</td>
                                    </tr>';
                    }

                    unset($element, $tmp, $data);

                    $output .= '        </tbody>
                                    </table>
                                    </div>
                                </div>';
                    break;

                case "host":

                    $output .= '        <script type="text/javascript">
                    $(function() 
                    {
                        $("#vsphere_settings").tabs();
                    });
                    $(document).ready(function() {
                        $(\'#checkAll2\').click(function(event) {  //on click
                            if(this.checked) { // check select status
                                $(\'#vsphere_settings-2 input:checkbox\').each(function() { //loop through each checkbox
                                    this.checked = true;  //select all checkboxes with class "checkbox1"              
                                });
                            }else{
                                $(\'#vsphere_settings-2 input:checkbox\').each(function() { //loop through each checkbox
                                    this.checked = false; //deselect all checkboxes with class "checkbox1"                      
                                });        
                            }
                        });
                       
                    });
                    </script>

                    <div id="vsphere_settings" style="margin-top: 20px;">
                        <ul>
                            <li><a href="#vsphere_settings-1">' . _('Monitored Metrics') . '</a></li>
                            <li><a href="#vsphere_settings-2">' . _('Datastores') . '</a></li>
                        </ul>
                    <div id="vsphere_settings-1">
                        <h5 class="ul" style="padding-bottom:0;">' . _('VMware Host Metrics') . '</h5>
                                <p>' . _('Select the metrics you\'d like to monitor on each of the hosts you select. The fields below take multiple values. See the tool tips for examples. For more information view our ') . '<a href="https://assets.nagios.com/downloads/nagiosxi/docs/Monitoring-VSphere.pdf" target="_blank">'. _('documentation') .'</a>.</p>
                                <script type="text/javascript">
                                    function toggleCheckboxes(status) {
                                        var checkboxes = document.getElementsByClassName("service_checkbox");
                                        for (var i = 0; i < checkboxes.length; i++) {
                                            checkboxes[i].checked = status;
                                        }
                                    }
                                </script>
                                <style>
                                    #vsphere_metrics table tbody tr td {
                                        padding: 3px 12px;
                                    }
                                    #vsphere_metrics table tbody tr:first-child td {
                                        padding: 6px 12px 3px 12px;
                                    }
                                </style>
                                <div id="vsphere_metrics">
                                    <table class="table table-condensed table-no-border table-auto-width" style="margin-bottom:5px;">
                                        <thead>
                                            <tr>
                                                <th style="vertical-align:center; padding-left:12px; padding-right:0px;"><input type="checkbox" id="checkAll1" title="'._('Check All').'" onclick="toggleCheckboxes(this.checked)" checked="yes"></th>
                                                <th>' . _('Metric') . '</th>
                                                <th style="padding-left:40px">' . _('Warning Threshold') . '</th>
                                                <th style="padding-left:40px">' . _('Critical Threshold') . '</th>
                                            </tr>
                                        </thead>
                                        <tbody>';
                    foreach (json_decode(VSPHERE_SERVICENAMES_HOST, true) as $s) {
                        if (in_array($s[0] , array('RUNTIME', 'SERVICE'))) {
                            vsphere_configwizard_pushcheckboxandargs($output, $s, $services, $serviceargs, $mode, $disabled=true);
                        } else {
                            vsphere_configwizard_pushcheckboxandargs($output, $s, $services, $serviceargs, $mode);
                        }
                    }
                    $output .= '        </tbody>
                                    </table>
                                </div>
                            </div>
                            <style>
                                div#vsphere_settings-2 table tbody tr td {
                                    padding: 3px 12px;
                                }
                                div#vsphere_settings-2 table tbody tr:first-child td {
                                    padding: 6px 12px 3px 12px;
                                }
                            </style>
                            <div id="vsphere_settings-2">';

                    // Run the get guests perl file to get a list of guest VMs...
                    $cmd = get_root_dir() . '/html/includes/configwizards/vsphere/plugins/check_vsphere_xi.py -H ' . escapeshellarg($address) . ' -u ' . escapeshellarg($username) . ' -p ' . escapeshellarg($password) . ' -L';
                    $proc = proc_open($cmd, array(1 => array('pipe', 'w'), 2 => array('pipe', 'w')), $pipes);
                    if (is_resource($proc)) {
                        $data = stream_get_contents($pipes[1]);
                        fclose($pipes[1]);
                        $stderr = stream_get_contents($pipes[2]);
                        fclose($pipes[2]);
                        proc_close($proc);
                    }

                    $data = explode("\n", $data);

                    if (!empty($stderr)) {
                        $output .= '    <h5 class="ul">' . _('Error') . '</h5>
                                        <p>' . _('It appears there are no guests for this VMware host. The error message is below. This may be because the SDK is not installed, your credentials are wrong, or the host is not a VMware server.') . '</p>
                                        <pre>' . $stderr . '</pre>
                                    </div>
                                </div>';
                        return $output;
                    }

                    $output .= '    <h5 class="ul" style="padding-bottom:0;">' . _('Datastores Selection') . '</h5>
                            <p>' . _('Specify which datastores you\'d like to monitor on the VMware host (server).') . '</p>
                            <table class="table table-condensed table-no-border table-auto-width" style="margin-bottom:5px;">
                                <thead>
                                    <tr>
                                        <th style="vertical-align:middle;horizontal-align:middle;"> <input type="checkbox" id="checkAll2" title="'._('Check All').'"></th>
                                        <th>' . _('Datastores') . '</th>
                                        <th>' . _('Data Used') . '</th>
                                        <th>' . _('Data Total') . '</th>
                                        <th>' . _('Percentage in Use') . '</th>
                                    </tr>
                                </thead>
                                <tbody>';
                    $rownumber = 2; //Used for determing row color
                    $rowstyles = 'vertical-align:middle;horizontal-align:middle;';
                    foreach ($data as &$element) {
                        ($rownumber++ % 2) ? $tclass = 'odd' : $tclass = 'even';
                        $element = explode("\t", $element);
                        $nam = base64_encode($element[0]);
                        $idnt = $element[0];
                        if(empty($nam))
                            continue;
                        $nametextfield = sprintf('<input type="text" size="35" name="alias_%s" id="alias_%s" value="%s" class="form-control">', encode_form_val($nam), encode_form_val($nam), encode_form_val(array_key_exists($idnt, $guests) ? $guests[$idnt] : $idnt));
                        /* Now we will draw the tables.
                            $element[0] is the datastores (Text Field) set to $nametextfield for readability.
                            $element[1] is the bytes being used and is set to $dataUsed variable.
                            $element[2] is the total bytes avaialable and is set to $dataTotal variable.
                            $element[3] is the percentage of data being used and is used to set $dataPercentage variable.*/
                        // Setting nice looking powerestatus variable.
                        ($element[1] == '') ? $dataUsed = '<font color="gray">' . _('None Defined') . '</font>' : $dataUsed = '<b>' . $element[1] . '</b>';
                        ($element[2] == '') ? $dataTotal = '<font color="gray">' . _('None Defined') . '</font>' : $dataTotal = '<b>' . $element[2] . '</b>';
                        ($element[3] == '') ? $dataPercentage = '<font color="gray">' . _('None Defined') . '</font>' : $dataPercentage = '<b>' . $element[3] . '<b>';

                        if (count($guests) === 0) {
                            $output .= '    <tr class="' . $tclass . '">
                                            <td style="' . $rowstyles . '">
                                                <input type="checkbox" name="activate_' . encode_form_val($nam) . '"' . ($element[3] === 'poweredOn' ? ' checked="yes"' : '') . '>';
                        } else {
                            $output .= '    <tr>
                                            <td style="' . $rowstyles . '">
                                                <input type="checkbox" name="activate_' . encode_form_val($nam) . '"' . (array_key_exists($idnt, $guests) ? ' checked="yes"' : '') . '>';
                        }

                        $output .= '        </td>
                                        <td style="' . $rowstyles . '">' . $nametextfield . '</td>
                                        <td style="' . $rowstyles . '">' . $dataUsed . '</td>
                                        <td style="' . $rowstyles . '">' . $dataTotal . '</td>
                                        <td style="' . $rowstyles . '">' . $dataPercentage . '</td>
                                    </tr>';
                    }

                    unset($element, $tmp, $data);

                    $output .= '        </tbody>
                                    </table>
                                    </div>
                                </div>';
                    $output .= '<div style="height: 20px;"></div>';
                    break;
                default:
                    break;
            }

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

            // User macros
            $address = nagiosccm_replace_user_macros($address);
            $hostname = nagiosccm_replace_user_macros($hostname);
            $username = nagiosccm_replace_user_macros($username);
            $password = nagiosccm_replace_user_macros($password);

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) === false) {
                $errmsg[$errors++] = _('Invalid host name.');
            }

            foreach ($services as $s) {
                if (is_valid_service_name($s) === false) {
                    $errmsg[$errors++] = sprintf(_('Invalid service name') . " %s", $s);
                }
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

            $output = ' <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
                        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
                        <input type="hidden" name="type" value="' . encode_form_val($type) . '">
                        <input type="hidden" name="username" value="' . encode_form_val($username) . '">
                        <input type="hidden" name="password" value="' . encode_form_val($password) . '">
                        <input type="hidden" name="services_serial" value="' . encode_form_val(base64_encode(json_encode($services))) . '">
                        <input type="hidden" name="serviceargs_serial" value="' . encode_form_val(base64_encode(json_encode(
                    $serviceargs))) . '">
                        <input type="hidden" name="guests_serial" value="' . encode_form_val(base64_encode(json_encode($guests))) . '">';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vsphere_configwizard_parseinargs($inargs);

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr['hostname'] = $hostname;
            $meta_arr['ip_address'] = $address;
            $meta_arr['type'] = $type;
            $meta_arr['services'] = $services;
            $meta_arr['serviceargs'] = $serviceargs;
            $meta_arr['guests'] = $guests;
            save_configwizard_object_meta('vsphere', $hostname, '', $meta_arr);

            $objs = array();

            // write auth data file
            $fil = get_root_dir() . '/etc/components/vsphere';
            if (!file_exists($fil))
                mkdir($fil, 0770);
            $fil .= '/' . preg_replace('/[ .\:_-]/', '_', $hostname) . '_auth.txt';

            $fh = fopen($fil, 'w+');
            if ($fh) {
                fputs($fh, 'username=' . $username . "\npassword=" . $password . '');
                fclose($fh);
            }

            vsphere_configwizard_makeservices($objs, $hostname, $address, $type, $services, $serviceargs, $guests);

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            // echo "<pre style='color: white;'>";
            // var_dump($objs);
            // echo "</pre>";

            break;

        default:

            break;
    }

    return $output;
}
