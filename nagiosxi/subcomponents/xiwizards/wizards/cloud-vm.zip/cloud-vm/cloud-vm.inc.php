<?php
//
// Rackspace Cloud Config Wizard
// Copyright (c) 2018-2024 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

digitalocean_configwizard_init();
google_cloud_configwizard_init();
linode_configwizard_init();
microsoft_azure_configwizard_init();
rackspace_configwizard_init();

function cloud_vm_common_args() {
    return array(
        CONFIGWIZARD_VERSION => "2.0.2",
        CONFIGWIZARD_COPYRIGHT => "Copyright &copy; 2018-2024 Nagios Enterprises, LLC.",
        CONFIGWIZARD_AUTHOR => "Nagios Enterprises, LLC",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_REQUIRES_VERSION => 60100
    );
}

function digitalocean_configwizard_init()
{
    $name = "digitalocean";
    $common_args = cloud_vm_common_args();
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a DigitalOcean Droplet using the Nagios Cross-Platftorm Agent."),
        CONFIGWIZARD_DISPLAYTITLE => _("DigitalOcean"),
        CONFIGWIZARD_FUNCTION => "cloud_vm_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => $name . ".png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','linux','otheros'),
    );
    $args = array_merge($args, $common_args);
    register_configwizard($name, $args);
}

function google_cloud_configwizard_init()
{
    $name = "google-cloud";
    $common_args = cloud_vm_common_args();
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a Google Cloud VM (Windows, RHEL/CentOS, Debian/Ubuntu, or SLES) using NCPA."),
        CONFIGWIZARD_DISPLAYTITLE => _("Google Cloud"),
        CONFIGWIZARD_FUNCTION => "cloud_vm_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => $name . ".png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','linux','otheros'),
    );
    $args = array_merge($args, $common_args);
    register_configwizard($name, $args);
}

function linode_configwizard_init()
{
    $name = "linode";
    $common_args = cloud_vm_common_args();
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a Linode (CentOS, Debian, Fedora, openSUSE, or Ubuntu) using the Nagios Cross-Plaftorm Agent."),
        CONFIGWIZARD_DISPLAYTITLE => _("Linode"),
        CONFIGWIZARD_FUNCTION => "cloud_vm_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => $name . ".png",
        CONFIGWIZARD_FILTER_GROUPS => array('linux','otheros'),
    );
    $args = array_merge($args, $common_args);
    register_configwizard($name, $args);
}

function microsoft_azure_configwizard_init()
{
    $name = "microsoft-azure";
    $common_args = cloud_vm_common_args();
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a Microsoft Azure Cloud VM (Windows, RHEL, CentOS, or Ubuntu) using NCPA."),
        CONFIGWIZARD_DISPLAYTITLE => _("Microsoft Azure Cloud"),
        CONFIGWIZARD_FUNCTION => "cloud_vm_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => $name . ".png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','linux','otheros'),
    );
    $args = array_merge($args, $common_args);
    register_configwizard($name, $args);
}

function rackspace_configwizard_init()
{
    $name = "rackspace";
    $common_args = cloud_vm_common_args();
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a Rackspace Cloud Server (Windows Server, CentOS, Debian, Fedora, or Ubuntu) using NCPA."),
        CONFIGWIZARD_DISPLAYTITLE => _("Rackspace Cloud"),
        CONFIGWIZARD_FUNCTION => "cloud_vm_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => $name . ".png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','linux','otheros'),
    );
    $args = array_merge($args, $common_args);
    register_configwizard($name, $args);
}

/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function cloud_vm_configwizard_func($mode = "", $inargs = null, &$outargs = null, &$result = null)
{
    $wizard_name = $inargs['wizard'];

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "5693");
            $token = grab_array_var($inargs, "token", "");
            $no_ssl_verify = grab_array_var($inargs, "no_ssl_verify", 1);
            $selectedhostconfig = grab_array_var($inargs, "selectedhostconfig", "");
            $operation = grab_array_var($inargs, "operation", "new");

            # Get the existing host/node configurations.
            # TODO: Include passwords/secrets?
            $nodes = get_configwizard_hosts($wizard_name);

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step1 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step1.php';
            $output = ob_get_clean();

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "5693");
            $token = grab_array_var($inargs, "token", "");
            $no_ssl_verify = grab_array_var($inargs, "no_ssl_verify", 1);

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($address) == false) {
                $errmsg[$errors++] = _("No address specified.");
            }

            if (have_value($port) == false) {
                $errmsg[$errors++] = _("No port number specified.");
            }

            // Test the connection if no errors
            if (empty($errors)) {
                $address_replaced = nagiosccm_replace_user_macros($address);
                $port_replaced = nagiosccm_replace_user_macros($port);
                $token_replaced = nagiosccm_replace_user_macros($token);

                // The URL we will use to query the NCPA agent, and do a walk
                // of all monitorable items.
                $query_url = "https://{$address}:{$port}/testconnect?token={$token}";
                $query_url_replaced = "https://{$address_replaced}:{$port_replaced}/testconnect?token={$token_replaced}";

                // Remove SSL verification or not
                $context = array("ssl" => array("verify_peer" => true, "verify_peer_name" => true));

                if ($no_ssl_verify) {
                    $context['ssl']['verify_peer'] = false;
                    $context['ssl']['verify_peer_name'] = false;
                }

                // All we want to do is test if we can hit this URL.
                // Error Control Operator - @ - http://php.net/manual/en/language.operators.errorcontrol.php

                // For a simple requeest, make timeout shorter than php default or typical gateway timeout of 60
                ini_set("default_socket_timeout", 10);
                $raw_json = @file_get_contents($query_url_replaced, false, stream_context_create($context));

                if ($raw_json === FALSE || empty($raw_json)) {
                    # FYI, the way this is setup, if the user uses the same url & token,
                    # both will be replaced with "your_token".
                    /* This error message is hiding macro expansion values. */
                    $safe_url = str_replace('token='.urlencode($token_replaced), "token=your_token", $query_url);
                    $errmsg[$errors++] = _("Unable to contact server at") . " {$safe_url}.";
                } else {
                    $json = json_decode($raw_json, true);
                    if (!array_key_exists('value', $json)) {
                        $errmsg[$errors++] = _("Bad token for connection.");
                    }
                }
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "");
            $token = grab_array_var($inargs, "token", "");
            $no_ssl_verify = grab_array_var($inargs, "no_ssl_verify", 1);
            $hostname = grab_array_var($inargs, 'hostname', gethostbyaddr($address));
            $default_mem_units = grab_array_var($inargs, 'default_mem_units', 'Gi');
            $tcp_check_port = grab_array_var($inargs, 'tcp_check_port', '5693');
            $selectedhostconfig = grab_array_var($inargs, "selectedhostconfig", "");
            $operation = grab_array_var($inargs, "operation", "new");

            $rp_address = nagiosccm_replace_user_macros($address);
            $rp_port = nagiosccm_replace_user_macros($port);
            $rp_token = nagiosccm_replace_user_macros($token);

            $services_serial = grab_array_var($inargs, "services_serial", "");

            if ($services_serial) {
                $services = json_decode(base64_decode($services_serial), true);
            }

            $not_used = array();
            $return_code = 0;
            $alternative_host_check = false;

            exec('ping -W 2 -c 1 ' . escapeshellarg($rp_address), $not_used, $return_code);

            if ($return_code !== 0) {
                $alternative_host_check = true;
            }

            // Remove SSL verification or not
            $context = array("ssl" => array("verify_peer" => true, "verify_peer_name" => true));

            if ($no_ssl_verify) {
                $context['ssl']['verify_peer'] = false;
                $context['ssl']['verify_peer_name'] = false;
            }

            // The URL we will use to query the NCPA agent, and do a walk
            // of all monitorable items. Make three queries, one for disk,
            // one for interfaces, and one for services.
            $iface_url = "https://{$rp_address}:{$rp_port}/api/interface?token={$rp_token}";
            $disks_url = "https://{$rp_address}:{$rp_port}/api/disk?token={$rp_token}";
            $services_api_url = "https://{$rp_address}:{$rp_port}/api/services?token={$rp_token}";

            $iface_json = file_get_contents($iface_url, false, stream_context_create($context));
            $iface_data = json_decode($iface_json, true);

            if (array_key_exists('value', $iface_data)) {
                $iface_root = $iface_data['value']['interface'];
            } else {
                $iface_root = $iface_data['interface'];
            }

            $disks_json = file_get_contents($disks_url, false, stream_context_create($context));
            $disks_data = json_decode($disks_json, true);

            if (array_key_exists('value', $disks_data)) {
                $disks_root = $disks_data['value']['disk'];
            } else {
                $disks_root = $disks_data['disk'];
            }

            $services_api_json = file_get_contents($services_api_url, false, stream_context_create($context));
            $services_api_data = json_decode($services_api_json, true);

            if (array_key_exists('value', $services_api_data)) {
                $services_api_root = $services_api_data['value']['services'];
            } else {
                $services_api_root = $services_api_data['services'];
            }

            $categories = array();
            $root = array();

            $root['disk'] = $disks_root;
            $root['interface'] = $iface_root;
            $root['services'] = $services_api_root;

            ########################################################################################
            # Load the html
            # - The html needs to end up in the $output string, so use ob_start() and ob_get_clean()
            #   to load the PHP from the Step2 file into the $output string.
            ########################################################################################
            ob_start();
            include __DIR__.'/steps/step2.php';
            $output = ob_get_clean();

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            // Get variables that were passed to us
            $address = grab_array_var($inargs, 'ip_address');
            $hostname = grab_array_var($inargs, 'hostname');
            $port = grab_array_var($inargs, 'port');
            $token = grab_array_var($inargs, 'token');
            $default_mem_units = grab_array_var($inargs, 'default_mem_units');
            $tcp_check_port = intval(grab_array_var($inargs, 'tcp_check_port'));
            $alternative_host_check = grab_array_var($inargs, 'alternative_host_check', '');

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) == false) {
                $errmsg[$errors++] = "Invalid host name.";
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;

        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            // Get variables that were passed to us
            $address = grab_array_var($inargs, 'ip_address');
            $hostname = grab_array_var($inargs, 'hostname');
            $port = grab_array_var($inargs, 'port');
            $token = grab_array_var($inargs, 'token');
            $services = grab_array_var($inargs, 'services', array());
            $default_mem_units = grab_array_var($inargs, 'default_mem_units');
            $tcp_check_port = intval(grab_array_var($inargs, 'tcp_check_port'));
            $alternative_host_check = grab_array_var($inargs, 'alternative_host_check', '');

            $output = '
            <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '" />
            <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '" />
            <input type="hidden" name="port" value="' . encode_form_val($port) . '" />
            <input type="hidden" name="token" value="' . encode_form_val($token) . '" />
            <input type="hidden" name="default_mem_units" value="' . encode_form_val($default_mem_units) . '" />
            <input type="hidden" name="services_serial" value="' . base64_encode(json_encode($services)) . '" />
            <input type="hidden" name="tcp_check_port" value="' . encode_form_val($tcp_check_port) . '" />
            <input type="hidden" name="alternative_host_check" value="' . encode_form_val($alternative_host_check) . '" />';

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:
            $hostname = grab_array_var($inargs, "hostname", "");
            $address = grab_array_var($inargs, "ip_address", "");
            $hostaddress = $address;
            $port = grab_array_var($inargs, "port", "");
            $token = grab_array_var($inargs, "token", "");
            $default_mem_units = grab_array_var($inargs, 'default_mem_units');
            $services_serial = grab_array_var($inargs, "services_serial", "");
            $services = json_decode(base64_decode($services_serial), true);
            $tcp_check_port = intval(grab_array_var($inargs, 'tcp_check_port'));
            $alternative_host_check = grab_array_var($inargs, 'alternative_host_check', '');

            // Save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["ip_address"] = $address;
            $meta_arr["port"] = $port;
            $meta_arr["token"] = $token;
            $meta_arr["services"] = $services;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            // Escape values for check_command line
            if (function_exists('nagiosccm_replace_command_line')) {
                $token = nagiosccm_replace_command_line($token);
            } else {
                $token = str_replace('!', '\!', $token);
            }

            $objs = array();
            if (!host_exists($hostname)) {
                $host_object = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_ncpa_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => $wizard_name . ".png",
                    "statusmap_image" => $wizard_name . ".png",
                    "_xiwizard" => $wizard_name);
                if (!empty($alternative_host_check)) {
                    $host_object['check_command'] = "check_tcp!$tcp_check_port!";
                }
                $objs[] = $host_object;
            }

            // Common plugin opts
            $commonopts = "-t '$token' ";
            if ($port) {
                $commonopts .= "-P $port ";
            }

            foreach ($services as $type => $args) {
                $pluginopts = "";
                $pluginopts .= $commonopts;

                switch ($type) {

                    case "cpu_usage":
                        if (!array_key_exists('monitor', $args)) {
                            break;
                        }
                        $pluginopts .= "-M cpu/percent";

                        if (!empty($args['warning'])) {
                            $pluginopts .= " -w " . $args["warning"];
                        }
                        if (!empty($args['critical'])) {
                            $pluginopts .= " -c " . $args["critical"];
                        }

                        if (!empty($args['average'])) {
                            $pluginopts .= " -q 'aggregate=avg'";
                        }

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "CPU Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa!" . $pluginopts,
                            "_xiwizard" => $wizard_name);
                        break;

                    case "memory_usage":
                        if (!array_key_exists('monitor', $args)) {
                            break;
                        }
                        $pluginopts .= "-M memory/virtual";

                        if (!empty($default_mem_units)) {
                            $pluginopts .= " -u " . $default_mem_units;
                        }
                        if (!empty($args['warning'])) {
                            $pluginopts .= " -w " . $args["warning"];
                        }
                        if (!empty($args['critical'])) {
                            $pluginopts .= " -c " . $args["critical"];
                        }

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Memory Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa!" . $pluginopts,
                            "_xiwizard" => $wizard_name);
                        break;

                    case "swap_usage":
                        if (!array_key_exists('monitor', $args)) {
                            break;
                        }
                        $pluginopts .= "-M memory/swap";

                        if (!empty($default_mem_units)) {
                            $pluginopts .= " -u " . $default_mem_units;
                        }
                        if (!empty($args['warning'])) {
                            $pluginopts .= " -w " . $args["warning"];
                        }
                        if (!empty($args['critical'])) {
                            $pluginopts .= " -c " . $args["critical"];
                        }

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Swap Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa!" . $pluginopts,
                            "_xiwizard" => $wizard_name);
                        break;

                    case "disk":
                        foreach ($args as $title => $metrics) {
                            if (!array_key_exists('monitor', $metrics)) {
                                continue;
                            }
                            $theseopts = "{$pluginopts} -M 'disk/logical/{$title}/used_percent'";

                            if (!empty($metrics["warning"])) {
                                $theseopts .= " -w " . $metrics["warning"];
                            }
                            if (!empty($metrics["critical"])) {
                                $theseopts .= " -c " . $metrics["critical"];
                            }

                            // Make sure back slash doesn't escape service description line
                            $service_name = str_replace('\\', '/', $metrics["name"]);

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Disk Usage on " . $service_name,
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa!" . $theseopts,
                                "_xiwizard" => $wizard_name);
                        }
                        break;

                    case "interface":
                        foreach ($args as $title => $metrics) {
                            if (!array_key_exists('monitor', $metrics)) {
                                continue;
                            }

                            $theseopts = "{$pluginopts} -M 'interface/{$title}/bytes_sent' -d -u M";

                            if (!empty($metrics["warning"])) {
                                $theseopts .= " -w " . $metrics["warning"];
                            }
                            if (!empty($metrics["critical"])) {
                                $theseopts .= " -c " . $metrics["critical"];
                            }

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "{$title} Bandwidth - Outbound",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa!" . $theseopts,
                                "_xiwizard" => $wizard_name);

                            $theseopts = "{$pluginopts} -M 'interface/{$title}/bytes_recv' -d -u M";

                            if (!empty($metrics["warning"])) {
                                $theseopts .= " -w " . $metrics["warning"];
                            }
                            if (!empty($metrics["critical"])) {
                                $theseopts .= " -c " . $metrics["critical"];
                            }

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "{$title} Bandwidth - Inbound",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa!" . $theseopts,
                                "_xiwizard" => $wizard_name);
                        }
                        break;

                    case "services":
                        foreach ($args as $i => $service) {
                            if (!array_key_exists('monitor', $service)) {
                                continue;
                            }
                            $theseopts = "{$pluginopts} -M 'services' -q 'service=" . $service["name"] . ",status=" . $service["state"] . "'";
                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Service status for: " . $service["name"],
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa!" . $theseopts,
                                "_xiwizard" => $wizard_name);
                        }
                        break;

                    case "process":
                        foreach ($args as $i => $metrics) {
                            if (!array_key_exists('monitor', $metrics)) {
                                continue;
                            }
                            $proc_name = $metrics['name'];
                            $display = $metrics['display_name'];
                            $theseopts = "{$pluginopts} -M 'processes' -q 'name={$proc_name}'";

                            if (!empty($metrics["count"]["warning"])) {
                                $theseopts .= " -w " . $metrics["count"]["warning"];
                            }
                            if (!empty($metrics["count"]["critical"])) {
                                $theseopts .= " -c " . $metrics["count"]["critical"];
                            }

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Proccess count for: {$display}",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa!" . $theseopts,
                                "_xiwizard" => $wizard_name);
                        }
                        break;

                    default:
                        break;
                }
            }

            // Return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            break;

        default:
            break;
    }

    return $output;
}
