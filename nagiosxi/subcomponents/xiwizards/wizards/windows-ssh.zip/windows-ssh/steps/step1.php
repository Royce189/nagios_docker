    <input type="hidden" id="services_serial" name="services_serial" value="<?= (!empty($services)) ? base64_encode(json_encode($services)) : "" ?>" />
    <input type="hidden" id="serviceargs_serial" name="serviceargs_serial" value="<?= (!empty($serviceargs)) ? base64_encode(json_encode($serviceargs)) : "" ?>" />
    <input type="hidden" id="config_serial" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>" />

    <div class="container m-0 g-0">
<?php
# New/Copy/Update
#    include_once __DIR__.'/../../../utils-xi2024-wizards.inc.php';

    $versionString = shell_exec('python3 -c "import sys; print(sys.version_info[0])" 2>/dev/null');

    if ($versionString === null) {
?>
        <ul class="actionMessage">
            <li><b><?php echo _("Python 3 is required to run this wizard."); ?></b></li>
        </ul>
<?php
    }
?>
        <!--                         -->
        <!-- The configuration form. -->
        <!--                         -->
        <div id="configForm">
            <h5 class="ul"><?= _('Windows Server Information') ?></h5>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label class="form-label form-item-required"><?= _("Address") ?> <?= xi6_info_tooltip(_("The IP address of the Windows Machine to monitor")) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter IP Address/Hostname") ?>" required>
                        <div class="invalid-feedback">
                            Please enter ip address or hostname.
                        </div>
                        <i id="ip_address_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-6">
                    <label class="form-label form-item-required"><?= _("SSH Username") ?> <?= xi6_info_tooltip(_("The SSH username to use when connecting to the server.")) ?></label>
                    <div class="input-group position-relative">
                        <input type="text" name="ssh_username" id="ssh_username" value="<?= encode_form_val($ssh_username) ?>" class="form-control form-control-sm monitor rounded" placeholder="<?= _("Enter SSH Username") ?>" required>
                        <div class="invalid-feedback">
                            Please enter the ssh username.
                        </div>
                        <i id="ssh_username_Alert" class="visually-hidden position-absolute top-0 start-100 translate-middle icon icon-circle color-ok icon-size-status"></i>
                    </div>
                </div>
            </div>

            <p><b><?= sprintf(_('Refer to the %sWindows SSH Configuration Wizard%s guide for setup assistance.'), '<a target="_blank" href="https://answerhub.nagios.com/support/s/article/Windows-SSH-Configuration-Wizard-for-Nagios-XI-9a5920ef">', '</a>'); ?></b></p>

        </div> <!-- config -->
    </div> <!-- container -->

    <script type="text/javascript" src="<?= get_base_url() ?>includes/js/wizards-bs5.js?<?= get_build_id(); ?>"></script>
